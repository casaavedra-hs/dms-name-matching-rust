@echo off
setlocal EnableExtensions
cd /d "%~dp0"

rem Keep implementation files hidden. Only this launcher is intended for users.
attrib +h +s "_app" >nul 2>&1

rem Once compiled, launch the native Rust application directly with no bootstrap.
if exist "%~dp0_app\bin\DMS_Name_Matching.exe" (
    start "DMS Name Matching" /D "%~dp0_app" "%~dp0_app\bin\DMS_Name_Matching.exe"
    exit /b 0
)

rem First successful run only: reuse an existing local Rust/Cargo cache or prepare one.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0_app\bootstrap.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo.
    echo DMS Name Matching could not start.
    echo Diagnostic log: %~dp0_app\runtime\bootstrap.log
    pause
)
exit /b %RC%
