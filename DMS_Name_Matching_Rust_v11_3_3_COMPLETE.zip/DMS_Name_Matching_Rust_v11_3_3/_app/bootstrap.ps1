param([switch]$ForceRebuild)

# DMS Name Matching Rust v11.3.3
# Recovery-first production bootstrap for the user's Windows workstation.
# It deliberately reuses the complete Rust/Cargo installations created by prior DMS
# versions before attempting any network access.

Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'

$AppRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot=Split-Path -Parent $AppRoot
$PackageParent=Split-Path -Parent $PackageRoot
$Runtime=Join-Path $AppRoot 'runtime'
$Bin=Join-Path $AppRoot 'bin'
$Exe=Join-Path $Bin 'DMS_Name_Matching.exe'
$Log=Join-Path $Runtime 'bootstrap.log'
$LocalTarget=Join-Path $Runtime 'target'
$CertDir=Join-Path $Runtime 'certificates'
$TrustBundle=Join-Path $CertDir 'windows-trust-bundle.pem'
$ShimDir=Join-Path $Runtime 'tool-shims'
$Downloads=Join-Path $Runtime 'downloads'
$LocalCargo=Join-Path $Runtime 'cargo-home'
$LocalRustup=Join-Path $Runtime 'rustup-home'
$PinnedVersion='1.98.1'
$Targets=@('x86_64-pc-windows-gnullvm','x86_64-pc-windows-gnu')

New-Item -ItemType Directory -Force -Path $Runtime,$Bin,$LocalTarget,$CertDir,$ShimDir,$Downloads,$LocalCargo,$LocalRustup | Out-Null
if(Test-Path $Log){Clear-Content $Log -ErrorAction SilentlyContinue}

function Log([string]$m,[ConsoleColor]$c=[ConsoleColor]::Gray){
 $line='[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$m
 Add-Content $Log $line -Encoding UTF8
 Write-Host $line -ForegroundColor $c
}

function Run {
 param([string]$File,[string[]]$Args=@(),[string]$Label='process',[switch]$AllowFailure,[switch]$Quiet)
 $cmd=$null
 if(Test-Path $File){$cmd=$File}else{$x=Get-Command $File -ErrorAction SilentlyContinue;if($x){$cmd=$x.Source}}
 if(-not $cmd){if($AllowFailure){return 9009};throw "$Label executable was not found: $File"}
 $clean=@(); foreach($a in @($Args)){if($null -ne $a){$clean += [string]$a}}
 $old=$ErrorActionPreference
 try{
  $ErrorActionPreference='Continue'
  & $cmd @clean 2>&1 | ForEach-Object { $t=$_.ToString(); if($t){Add-Content $Log $t -Encoding UTF8;if(-not $Quiet){Write-Host $t}} }
  $rc=$LASTEXITCODE;if($null -eq $rc){$rc=0}
 }finally{$ErrorActionPreference=$old}
 if($rc -ne 0 -and -not $AllowFailure){throw "$Label failed with exit code $rc. See $Log"}
 return [int]$rc
}

function Export-Trust {
 $b=New-Object Text.StringBuilder;$seen=@{}
 foreach($s in @('Cert:\CurrentUser\Root','Cert:\CurrentUser\CA','Cert:\LocalMachine\Root','Cert:\LocalMachine\CA')){
  try{Get-ChildItem $s -ErrorAction SilentlyContinue | ForEach-Object {
   if($_ -is [Security.Cryptography.X509Certificates.X509Certificate2] -and $_.Thumbprint -and -not $seen.ContainsKey($_.Thumbprint)){
    try{$raw=$_.Export([Security.Cryptography.X509Certificates.X509ContentType]::Cert);$x=[Convert]::ToBase64String($raw,[Base64FormattingOptions]::InsertLineBreaks);[void]$b.AppendLine('-----BEGIN CERTIFICATE-----');[void]$b.AppendLine($x);[void]$b.AppendLine('-----END CERTIFICATE-----');$seen[$_.Thumbprint]=$true}catch{}
   }
  }}catch{}
 }
 if($seen.Count){[IO.File]::WriteAllText($TrustBundle,$b.ToString(),[Text.Encoding]::ASCII);$env:CARGO_HTTP_CAINFO=$TrustBundle;$env:CARGO_HTTP_PROXY_CAINFO=$TrustBundle;Log "Cargo trust bundle prepared ($($seen.Count) certificates)." DarkGray}
}

function Import-Network {
 $f=Join-Path $Runtime 'network.env';if(-not(Test-Path $f)){return}
 foreach($line in Get-Content $f -ErrorAction SilentlyContinue){$s=$line.Trim();if(-not $s -or $s.StartsWith('#') -or $s.IndexOf('=') -lt 1){continue};$p=$s.Split('=',2);[Environment]::SetEnvironmentVariable($p[0].Trim(),$p[1].Trim(),'Process')}
}

function Candidate([string]$rh,[string]$ch,[string]$target,[string]$label,[string]$cache=''){
 if(-not $rh -or -not $ch){return $null}
 $tc="$PinnedVersion-$target";$td=Join-Path $rh "toolchains\$tc"
 $rustc=Join-Path $td 'bin\rustc.exe';$cargo=Join-Path $td 'bin\cargo.exe'
 if(-not(Test-Path $cargo)){$cargo=Join-Path $ch 'bin\cargo.exe'}
 if((Test-Path $rustc) -and (Test-Path $cargo)){return [PSCustomObject]@{Rustup=$rh;CargoHome=$ch;Target=$target;Toolchain=$tc;Dir=$td;Rustc=$rustc;Cargo=$cargo;Label=$label;Cache=$cache}}
 return $null
}

function Find-Candidates {
 $out=New-Object Collections.ArrayList
 # Current package first.
 foreach($t in $Targets){$c=Candidate $LocalRustup $LocalCargo $t 'current package' $LocalTarget;if($c){[void]$out.Add($c)}}
 # Neighboring old packages: this is the primary path on the user's PC.
 try{
  foreach($d in Get-ChildItem $PackageParent -Directory -ErrorAction SilentlyContinue){
   if($d.FullName -eq $PackageRoot){continue}
   foreach($layout in @('runtime','_app\runtime')){
    $rt=Join-Path $d.FullName $layout;$rh=Join-Path $rt 'rustup-home';$ch=Join-Path $rt 'cargo-home';$tg=Join-Path $rt 'target'
    foreach($t in $Targets){$c=Candidate $rh $ch $t $d.Name $tg;if($c){[void]$out.Add($c)}}
   }
  }
 }catch{}
 # User rustup if present.
 if($env:USERPROFILE){foreach($t in $Targets){$c=Candidate (Join-Path $env:USERPROFILE '.rustup') (Join-Path $env:USERPROFILE '.cargo') $t 'user Rust' '';if($c){[void]$out.Add($c)}}}
 # gnullvm first because it does not require external MinGW dlltool; GNU is fallback.
 return @($out | Sort-Object @{Expression={if($_.Target -eq 'x86_64-pc-windows-gnullvm'){0}else{1}}},Label -Unique)
}

function Find-Tool([string]$root,[string[]]$names){
 foreach($n in $names){try{$f=Get-ChildItem $root -Recurse -File -Filter $n -ErrorAction SilentlyContinue|Select-Object -First 1;if($f){return $f.FullName}}catch{}}
 foreach($n in $names){$c=Get-Command $n -ErrorAction SilentlyContinue;if($c){return $c.Source}}
 return $null
}

function Configure-Gnu($r){
 $dll=Find-Tool $r.Dir @('dlltool.exe','x86_64-w64-mingw32-dlltool.exe','llvm-dlltool.exe')
 if(-not $dll){Log 'GNU candidate skipped: dlltool was not found. Trying another cached target.' DarkYellow;return $false}
 $dir=Split-Path $dll -Parent;$env:PATH=$dir+';'+$env:PATH
 if((Split-Path $dll -Leaf).ToLower() -ne 'dlltool.exe'){Copy-Item -Force $dll (Join-Path $ShimDir 'dlltool.exe');$env:PATH=$ShimDir+';'+$env:PATH}
 $as=Find-Tool $r.Dir @('as.exe','x86_64-w64-mingw32-as.exe');if($as){$env:PATH=(Split-Path $as -Parent)+';'+$env:PATH}
 Log "GNU dlltool ready: $dll" DarkGray
 return $true
}

function Build-With($r){
 Log "Trying cached Rust toolchain: $($r.Toolchain) from $($r.Label)." Cyan
 $oldPath=$env:PATH;$oldCH=$env:CARGO_HOME;$oldRH=$env:RUSTUP_HOME;$oldRC=$env:RUSTC;$oldTC=$env:RUSTUP_TOOLCHAIN;$oldTD=$env:CARGO_TARGET_DIR
 try{
  $env:RUSTUP_HOME=$r.Rustup;$env:CARGO_HOME=$r.CargoHome;$env:RUSTC=$r.Rustc;$env:RUSTUP_TOOLCHAIN=$r.Toolchain
  $env:PATH=(Join-Path $r.Dir 'bin')+';'+(Join-Path $r.CargoHome 'bin')+';'+$env:PATH
  # Reuse old target cache to minimize first-build time. Safe because Cargo fingerprints source/deps.
  if($r.Cache -and (Test-Path $r.Cache)){$env:CARGO_TARGET_DIR=$r.Cache}else{$env:CARGO_TARGET_DIR=$LocalTarget}
  if($r.Target -eq 'x86_64-pc-windows-gnu'){if(-not(Configure-Gnu $r)){return $false}}
  $a=Run $r.Rustc @('--version') 'rustc validation' -AllowFailure;if($a -ne 0){return $false}
  $b=Run $r.Cargo @('--version') 'cargo validation' -AllowFailure;if($b -ne 0){return $false}
  Push-Location $AppRoot
  try{
   Log "Building production EXE OFFLINE for $($r.Target)..." Cyan
   $rc=Run $r.Cargo @('build','--release','--no-default-features','--offline','--target',$r.Target) 'offline production build' -AllowFailure
   if($rc -ne 0){Log "Cached $($r.Target) build did not complete." DarkYellow;return $false}
   $built=Join-Path $env:CARGO_TARGET_DIR "$($r.Target)\release\dms-name-matching.exe"
   if(-not(Test-Path $built)){Log 'Cargo returned success but the EXE was not found.' DarkYellow;return $false}
   Copy-Item -Force $built $Exe
   Log "Production executable created using $($r.Target)." Green
   return $true
  }finally{Pop-Location}
 }finally{
  $env:PATH=$oldPath;$env:CARGO_HOME=$oldCH;$env:RUSTUP_HOME=$oldRH;$env:RUSTC=$oldRC;$env:RUSTUP_TOOLCHAIN=$oldTC;$env:CARGO_TARGET_DIR=$oldTD
 }
}

function Download-Rustup([string]$out){
 $url='https://win.rustup.rs/x86_64';Remove-Item $out -Force -ErrorAction SilentlyContinue
 if(Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue){try{Log 'Downloading Rust bootstrap with Windows BITS...' Cyan;Start-BitsTransfer $url $out -ErrorAction Stop;if((Test-Path $out)-and(Get-Item $out).Length -gt 1000000){return $true}}catch{}}
 return $false
}

function Install-Fallback {
 # This is deliberately last. On the user's PC the prior v11.1/v11.2 caches should be found first.
 $ri=Join-Path $Downloads 'rustup-init.exe';if(-not(Test-Path $ri)){if(-not(Download-Rustup $ri)){return $null}}
 $env:CARGO_HOME=$LocalCargo;$env:RUSTUP_HOME=$LocalRustup;$env:PATH=(Join-Path $LocalCargo 'bin')+';'+$env:PATH
 Run $ri @('-y','--no-modify-path','--profile','minimal','--default-host','x86_64-pc-windows-gnullvm','--default-toolchain','none') 'rustup installation' | Out-Null
 $ru=Join-Path $LocalCargo 'bin\rustup.exe';if(-not(Test-Path $ru)){return $null}
 # Try gnullvm first. Network may be restricted; failure is returned rather than looping versions.
 $tc="$PinnedVersion-x86_64-pc-windows-gnullvm";$rc=Run $ru @('toolchain','install',$tc,'--profile','minimal') 'Rust toolchain installation' -AllowFailure
 if($rc -ne 0){return $null}
 return Candidate $LocalRustup $LocalCargo 'x86_64-pc-windows-gnullvm' 'new local installation' $LocalTarget
}

try{
 Log 'Starting DMS Name Matching Rust v11.3.3.' Cyan
 if((Test-Path $Exe)-and -not $ForceRebuild){Log 'Compiled application found. Starting immediately.' Green;Start-Process $Exe -WorkingDirectory $AppRoot;exit 0}
 Import-Network;Export-Trust
 $cands=Find-Candidates
 if($cands.Count -gt 0){Log "Found $($cands.Count) complete cached Rust toolchain candidate(s). No Rust download will be attempted first." Green}
 foreach($c in $cands){if(Build-With $c){Start-Process $Exe -WorkingDirectory $AppRoot;exit 0}}
 Log 'No cached toolchain produced the EXE. Trying one package-local gnullvm installation as the final fallback.' DarkYellow
 $fresh=Install-Fallback
 if($fresh -and (Build-With $fresh)){Start-Process $Exe -WorkingDirectory $AppRoot;exit 0}
 throw 'A Windows production EXE could not be built from the available local toolchains/caches. See bootstrap.log.'
}catch{
 Log ("STARTUP FAILED: "+$_.Exception.Message) Red
 Write-Host ''
 Write-Host 'DMS Name Matching could not start.' -ForegroundColor Red
 Write-Host "Diagnostic log: $Log" -ForegroundColor Yellow
 exit 1
}
