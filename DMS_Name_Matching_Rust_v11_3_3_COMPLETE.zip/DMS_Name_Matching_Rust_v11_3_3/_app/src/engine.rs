use std::{
    collections::HashMap,
    sync::{Arc, atomic::{AtomicBool, Ordering}},
    time::Instant,
};

use anyhow::{bail, Result};
use chrono::{Datelike, NaiveDate};
use crossbeam_channel::Sender;
use mysql::{params, prelude::Queryable, Pool, PooledConn};
use rayon::ThreadPoolBuilder;
use serde::Serialize;

use crate::{
    db::{self, BASE_REGISTRY, BASE_TABLE, DEDUP_TABLE, JOBS_TABLE, LEVEL_STATS_TABLE, METRICS_TABLE, RESULTS_TABLE, STAGE_TABLE},
    fuzzy::{Candidate, SimilarityEngine},
    model::{AppConfig, ConsolidationMode, EngineEvent, JobSnapshot, MatchLevel, ProcessMode, NORMALIZATION_VERSION},
    normalize::{first_char, md5_key, normalize, normalize_mi, prefix_chars},
    resources::ResourceGovernor,
};

#[derive(Clone)]
pub struct EngineControl {
    stop: Arc<AtomicBool>,
    pause: Arc<AtomicBool>,
}

impl Default for EngineControl {
    fn default() -> Self {
        Self { stop: Arc::new(AtomicBool::new(false)), pause: Arc::new(AtomicBool::new(false)) }
    }
}

impl EngineControl {
    pub fn request_stop(&self) { self.stop.store(true, Ordering::SeqCst); }
    pub fn request_pause(&self, paused: bool) { self.pause.store(paused, Ordering::SeqCst); }
    pub fn is_stopped(&self) -> bool { self.stop.load(Ordering::SeqCst) }
    pub fn is_paused(&self) -> bool { self.pause.load(Ordering::SeqCst) }
}

#[derive(Debug, Clone)]
struct SourceRow {
    row_key: String,
    person_id: String,
    first: String,
    middle: String,
    mi: String,
    last: String,
    birthdate: Option<NaiveDate>,
    barangay: String,
    city: String,
}

#[derive(Debug, Clone)]
struct ExactDecision {
    source_row_id: u64,
    source_record_id: String,
    base_row_id: u64,
    base_record_id: String,
    candidate_count: u64,
}

#[derive(Debug, Clone)]
struct LevelProgress {
    status: String,
    cursor: u64,
}

fn new_job_id() -> String {
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::time::{SystemTime, UNIX_EPOCH};
    static COUNTER: AtomicU64 = AtomicU64::new(1);
    let millis = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis()).unwrap_or(0);
    let seq = COUNTER.fetch_add(1, Ordering::Relaxed);
    format!("JOB-{millis}-{}-{seq}", std::process::id())
}

pub fn spawn_job(config: AppConfig, resume_job_id: Option<String>, tx: Sender<EngineEvent>, control: EngineControl) -> String {
    let job_id = resume_job_id.unwrap_or_else(new_job_id);
    let thread_job = job_id.clone();
    std::thread::spawn(move || {
        let _ = tx.send(EngineEvent::Log(format!("Starting Rust matching engine job {thread_job}")));
        match run_job(&thread_job, config, &tx, &control) {
            Ok(snapshot) => { let _ = tx.send(EngineEvent::Finished(snapshot)); }
            Err(e) => { let _ = tx.send(EngineEvent::Failed(format!("{e:#}"))); }
        }
    });
    job_id
}

pub fn run_job(job_id: &str, config: AppConfig, tx: &Sender<EngineEvent>, control: &EngineControl) -> Result<JobSnapshot> {
    validate_config(&config)?;
    db::ensure_schema(&config.destination)?;
    let output_pool = db::pool(&config.destination)?;
    let config_hash = config_hash(&config)?;
    create_or_resume_job(&output_pool, job_id, &config, &config_hash)?;

    ThreadPoolBuilder::new()
        .num_threads(config.performance.cpu_workers.max(1))
        .build_global()
        .ok(); // another job/process may already have initialized Rayon

    let mut similarity = SimilarityEngine::new(config.performance.gpu_mode, config.performance.gpu_min_field_pairs);
    log(tx, format!("CPU workers: {} | RAM ceiling: {:.0}% | GPU: {} ({})",
        config.performance.cpu_workers,
        config.performance.memory_limit_percent,
        similarity.gpu_name,
        similarity.gpu_backend));

    if config.mode.needs_base() {
        check_control(control)?;
        build_or_reuse_base(&config, &output_pool, tx, control)?;
    }

    check_control(control)?;
    stage_input(job_id, &config, &output_pool, tx, control)?;

    if config.mode.needs_dedup() {
        check_control(control)?;
        run_dedup(job_id, &config, &output_pool, tx, control, &mut similarity)?;
        if matches!(config.mode, ProcessMode::DedupOnly) {
            finalize_dedup_only(job_id, &output_pool)?;
            let s = refresh_snapshot(job_id, &output_pool, &similarity)?;
            return Ok(s);
        }
    }

    if config.mode.needs_base() {
        run_name_matching(job_id, &config, &output_pool, tx, control, &mut similarity)?;
        terminalize_results(job_id, &output_pool)?;
        if matches!(config.mode, ProcessMode::DedupConsolidateMatch) {
            inherit_consolidated_results(job_id, &output_pool)?;
        }
    }

    reconcile(job_id, &config, &output_pool)?;
    let mut c = output_pool.get_conn()?;
    c.exec_drop(
        format!("UPDATE {} SET status='DONE',current_phase='DONE',finished_at=NOW(),updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)),
        (job_id,),
    )?;
    let s = refresh_snapshot(job_id, &output_pool, &similarity)?;
    let _ = tx.send(EngineEvent::Snapshot(s.clone()));
    Ok(s)
}

fn validate_config(cfg: &AppConfig) -> Result<()> {
    if cfg.selected_levels.is_empty() { bail!("Select at least one matching level."); }
    db::validate_identifier(&cfg.destination.database, "Destination database")?;
    db::validate_identifier(&cfg.source1.database, "Source 1 database")?;
    db::validate_identifier(&cfg.source1.table, "Source 1 table")?;
    validate_map(&cfg.source1_fields)?;
    if !matches!(cfg.mode, ProcessMode::DedupOnly) {
        db::validate_identifier(&cfg.source2.database, "Source 2 database")?;
        db::validate_identifier(&cfg.source2.table, "Source 2 table")?;
        validate_map(&cfg.source2_fields)?;
    }
    // Validate optional fields only when a selected rule actually needs them.
    let needs_mi = [MatchLevel::L02, MatchLevel::L13, MatchLevel::L16].iter().any(|l| cfg.selected(*l));
    let needs_barangay = [MatchLevel::L12, MatchLevel::L13, MatchLevel::L14].iter().any(|l| cfg.selected(*l));
    let needs_city = [MatchLevel::L15, MatchLevel::L16, MatchLevel::L17].iter().any(|l| cfg.selected(*l));
    if needs_mi {
        db::validate_identifier(&cfg.source1_fields.middle_initial, "Source 1 middle initial")?;
        if !matches!(cfg.mode, ProcessMode::DedupOnly) { db::validate_identifier(&cfg.source2_fields.middle_initial, "Source 2 middle initial")?; }
    }
    if needs_barangay {
        db::validate_identifier(&cfg.source1_fields.barangay_code, "Source 1 barangay code")?;
        if !matches!(cfg.mode, ProcessMode::DedupOnly) { db::validate_identifier(&cfg.source2_fields.barangay_code, "Source 2 barangay code")?; }
    }
    if needs_city {
        db::validate_identifier(&cfg.source1_fields.city_code, "Source 1 city/municipality code")?;
        if !matches!(cfg.mode, ProcessMode::DedupOnly) { db::validate_identifier(&cfg.source2_fields.city_code, "Source 2 city/municipality code")?; }
    }
    if cfg.performance.memory_limit_percent < 50.0 || cfg.performance.memory_limit_percent > 95.0 {
        bail!("Memory limit must be between 50% and 95%.");
    }
    Ok(())
}

fn validate_map(m: &crate::model::FieldMap) -> Result<()> {
    for (name, value) in [
        ("Unique row key", &m.row_key), ("Person ID", &m.person_id), ("First name", &m.first_name),
        ("Middle name", &m.middle_name), ("Last name", &m.last_name), ("Birthdate", &m.birthdate),
    ] {
        db::validate_identifier(value, name)?;
    }
    Ok(())
}

fn config_hash(cfg: &AppConfig) -> Result<String> {
    #[derive(Serialize)]
    struct SafeCfg<'a> {
        mode: ProcessMode,
        consolidation: ConsolidationMode,
        source1_host: &'a str, source1_port: u16, source1_db: &'a str, source1_table: &'a str,
        source2_host: &'a str, source2_port: u16, source2_db: &'a str, source2_table: &'a str,
        fields1: &'a crate::model::FieldMap, fields2: &'a crate::model::FieldMap,
        levels: &'a [MatchLevel], thresholds: &'a crate::model::ThresholdConfig,
        normalization: &'static str,
    }
    let safe = SafeCfg {
        mode: cfg.mode, consolidation: cfg.consolidation,
        source1_host: &cfg.source1.host, source1_port: cfg.source1.port, source1_db: &cfg.source1.database, source1_table: &cfg.source1.table,
        source2_host: &cfg.source2.host, source2_port: cfg.source2.port, source2_db: &cfg.source2.database, source2_table: &cfg.source2.table,
        fields1: &cfg.source1_fields, fields2: &cfg.source2_fields,
        levels: &cfg.selected_levels, thresholds: &cfg.thresholds,
        normalization: NORMALIZATION_VERSION,
    };
    let bytes = serde_json::to_vec(&safe)?;
    Ok(format!("{:x}", md5::compute(bytes)))
}

fn base_signature(cfg: &AppConfig) -> Result<String> {
    #[derive(Serialize)]
    struct BaseSig<'a> {
        host: &'a str, port: u16, database: &'a str, table: &'a str,
        fields: &'a crate::model::FieldMap, normalization: &'static str,
    }
    let s = BaseSig { host: &cfg.source1.host, port: cfg.source1.port, database: &cfg.source1.database, table: &cfg.source1.table, fields: &cfg.source1_fields, normalization: NORMALIZATION_VERSION };
    Ok(format!("{:x}", md5::compute(serde_json::to_vec(&s)?)))
}

fn create_or_resume_job(pool: &Pool, job_id: &str, cfg: &AppConfig, hash: &str) -> Result<()> {
    let mut c = pool.get_conn()?;
    let existing: Option<(String, String)> = c.exec_first(
        format!("SELECT config_hash,status FROM {} WHERE job_id=?", db::qident(JOBS_TABLE)),
        (job_id,),
    )?;
    if let Some((old_hash, _)) = existing {
        if old_hash != hash { bail!("This Job ID belongs to a different matching configuration. Start a new job or restore the original configuration."); }
        c.exec_drop(format!("UPDATE {} SET status='RUNNING',updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)), (job_id,))?;
        return Ok(());
    }
    let levels = cfg.selected_levels.iter().map(|x| x.code()).collect::<Vec<_>>().join(",");
    let config_json = serde_json::to_string(cfg)?;
    c.exec_drop(
        format!("INSERT INTO {}(job_id,process_mode,consolidation_mode,selected_levels,config_hash,status,current_phase,config_json,started_at,updated_at) VALUES(?,?,?,?,?,'RUNNING','INITIALIZING',?,NOW(),NOW())", db::qident(JOBS_TABLE)),
        (job_id, format!("{:?}", cfg.mode), format!("{:?}", cfg.consolidation), levels, hash, config_json),
    )?;
    Ok(())
}

fn check_control(control: &EngineControl) -> Result<()> {
    if control.is_stopped() { bail!("Processing stopped by user. Checkpoints were preserved and the same Job ID can be resumed."); }
    while control.is_paused() {
        if control.is_stopped() { bail!("Processing stopped by user while paused. Checkpoints were preserved."); }
        std::thread::sleep(std::time::Duration::from_millis(500));
    }
    Ok(())
}

fn log(tx: &Sender<EngineEvent>, msg: impl Into<String>) { let _ = tx.send(EngineEvent::Log(msg.into())); }

fn fmt_u64(value: u64) -> String {
    let digits = value.to_string();
    let mut out = String::with_capacity(digits.len() + digits.len() / 3);
    for (i, ch) in digits.chars().enumerate() {
        if i > 0 && (digits.len() - i) % 3 == 0 {
            out.push(',');
        }
        out.push(ch);
    }
    out
}

fn source_for_stage<'a>(cfg: &'a AppConfig) -> (&'a crate::model::DbConfig, &'a crate::model::FieldMap) {
    if matches!(cfg.mode, ProcessMode::DedupOnly) { (&cfg.source1, &cfg.source1_fields) } else { (&cfg.source2, &cfg.source2_fields) }
}

fn build_or_reuse_base(cfg: &AppConfig, output_pool: &Pool, tx: &Sender<EngineEvent>, control: &EngineControl) -> Result<()> {
    let sig = base_signature(cfg)?;
    let mut out = output_pool.get_conn()?;
    let reg: Option<(String, String, Option<String>)> = out.query_first(format!("SELECT base_signature,status,build_cursor FROM {} WHERE id=1", db::qident(BASE_REGISTRY)))?;
    if !cfg.rebuild_base_index {
        if let Some((old, status, _)) = &reg {
            if old == &sig && status == "READY" {
                log(tx, "Base index signature matches. Reusing prepared Rust/MySQL base index.");
                return Ok(());
            }
        }
    }

    let resume = reg.as_ref().is_some_and(|(old, status, _)| old == &sig && status == "BUILDING") && !cfg.rebuild_base_index;
    if !resume {
        log(tx, "Preparing base index. Existing base will be rebuilt because the source/configuration signature changed.");
        out.query_drop(format!("TRUNCATE TABLE {}", db::qident(BASE_TABLE)))?;
        out.exec_drop(
            format!("INSERT INTO {}(id,base_signature,source_description,normalization_version,row_count,build_cursor,status,updated_at) VALUES(1,?,?,?,?,NULL,'BUILDING',NOW()) ON DUPLICATE KEY UPDATE base_signature=VALUES(base_signature),source_description=VALUES(source_description),normalization_version=VALUES(normalization_version),row_count=0,build_cursor=NULL,status='BUILDING',built_at=NULL,updated_at=NOW()", db::qident(BASE_REGISTRY)),
            (&sig, format!("{}.{}", cfg.source1.database, cfg.source1.table), NORMALIZATION_VERSION, 0u64),
        )?;
    }
    drop(out);

    let cursor = if resume { reg.and_then(|x| x.2).unwrap_or_default() } else { String::new() };
    if can_fast_stage(&cfg.source1, &cfg.destination) {
        match fast_stage_base(cfg, output_pool, &sig, cursor.clone(), tx, control) {
            Ok(()) => return Ok(()),
            Err(e) => log(tx, format!("Fast server-side base preparation was unavailable ({e}). Falling back to Rust streaming.")),
        }
    }
    stream_stage_base(cfg, output_pool, &sig, cursor, tx, control)
}

fn can_fast_stage(source: &crate::model::DbConfig, dest: &crate::model::DbConfig) -> bool {
    db::same_server(source, dest) && source.user.eq_ignore_ascii_case(&dest.user)
}

fn norm_sql(col: &str) -> String { crate::normalize::mysql_norm_expr(&db::qident(col)) }

fn normalized_select_sql(fields: &crate::model::FieldMap) -> (String, String, String, String, String, String, String, String, String) {
    let row_key = format!("CAST({} AS CHAR)", db::qident(&fields.row_key));
    let person_id = format!("CAST({} AS CHAR)", db::qident(&fields.person_id));
    let first = norm_sql(&fields.first_name);
    let middle = norm_sql(&fields.middle_name);
    let last = norm_sql(&fields.last_name);
    let mi = if fields.middle_initial.trim().is_empty() {
        format!("LEFT(REPLACE({middle},'.',''),1)")
    } else {
        format!("LEFT(REPLACE({},'.',''),1)", norm_sql(&fields.middle_initial))
    };
    let dob = format!("DATE({})", db::qident(&fields.birthdate));
    let barangay = if fields.barangay_code.trim().is_empty() { "''".into() } else { norm_sql(&fields.barangay_code) };
    let city = if fields.city_code.trim().is_empty() { "''".into() } else { norm_sql(&fields.city_code) };
    (row_key, person_id, first, middle, mi, last, dob, barangay, city)
}

fn high_key(conn: &mut PooledConn, source: &crate::model::DbConfig, row_key: &str, cursor: &str, limit: usize) -> Result<Option<String>> {
    let table = db::qtable(&source.database, &source.table);
    let key = db::qident(row_key);
    let sql = if cursor.is_empty() {
        format!("SELECT CAST(MAX(k) AS CHAR) FROM (SELECT {key} k FROM {table} ORDER BY {key} LIMIT {limit}) x")
    } else {
        format!("SELECT CAST(MAX(k) AS CHAR) FROM (SELECT {key} k FROM {table} WHERE {key}>? ORDER BY {key} LIMIT {limit}) x")
    };
    if cursor.is_empty() { Ok(conn.query_first(sql)?) } else { Ok(conn.exec_first(sql, (cursor,))?) }
}

fn fast_stage_base(cfg: &AppConfig, output_pool: &Pool, sig: &str, mut cursor: String, tx: &Sender<EngineEvent>, control: &EngineControl) -> Result<()> {
    let mut out = output_pool.get_conn()?;
    loop {
        check_control(control)?;
        let hi = match high_key(&mut out, &cfg.source1, &cfg.source1_fields.row_key, &cursor, cfg.performance.exact_batch_size)? {
            Some(x) => x,
            None => break,
        };
        let (row_key, person_id, first, middle, mi, last, dob, barangay, city) = normalized_select_sql(&cfg.source1_fields);
        let src = db::qtable(&cfg.source1.database, &cfg.source1.table);
        let base = db::qident(BASE_TABLE);
        let keycol = db::qident(&cfg.source1_fields.row_key);
        let where_sql = if cursor.is_empty() { format!("{keycol}<=?") } else { format!("{keycol}>? AND {keycol}<=?") };
        let derived = format!(r#"SELECT {row_key} source_row_key,{person_id} person_id,{first} first_name,{middle} middle_name,{mi} middle_initial,{last} last_name,{dob} birthdate,{barangay} barangay_code,{city} city_code FROM {src} WHERE {where_sql}"#);
        let sql = format!(r#"INSERT IGNORE INTO {base}(source_row_key,person_id,first_name,middle_name,middle_initial,last_name,birthdate,birth_year,birth_month,birth_day,barangay_code,city_code,first_initial,last_initial,first_prefix3,last_prefix3,key_l1,key_l2,key_l3,key_full_name)
            SELECT source_row_key,person_id,first_name,middle_name,middle_initial,last_name,birthdate,YEAR(birthdate),MONTH(birthdate),DAY(birthdate),barangay_code,city_code,LEFT(first_name,1),LEFT(last_name,1),LEFT(first_name,3),LEFT(last_name,3),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,middle_name,last_name,COALESCE(DATE_FORMAT(birthdate,'%Y-%m-%d'),'')))),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,middle_initial,last_name,COALESCE(DATE_FORMAT(birthdate,'%Y-%m-%d'),'')))),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,last_name,COALESCE(DATE_FORMAT(birthdate,'%Y-%m-%d'),'')))),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,middle_name,last_name))) FROM ({derived}) s"#);
        out.query_drop("START TRANSACTION")?;
        let result = if cursor.is_empty() { out.exec_drop(&sql, (&hi,)) } else { out.exec_drop(&sql, (&cursor, &hi)) };
        if let Err(e) = result { let _ = out.query_drop("ROLLBACK"); return Err(e.into()); }
        let inserted = out.affected_rows();
        cursor = hi;
        out.exec_drop(format!("UPDATE {} SET build_cursor=?,row_count=row_count+?,updated_at=NOW() WHERE id=1 AND base_signature=?", db::qident(BASE_REGISTRY)), (&cursor, inserted, sig))?;
        out.query_drop("COMMIT")?;
        log(tx, format!("Base index checkpoint: source key {cursor}"));
    }
    out.exec_drop(format!("UPDATE {} SET status='READY',built_at=NOW(),updated_at=NOW() WHERE id=1 AND base_signature=?", db::qident(BASE_REGISTRY)), (sig,))?;
    log(tx, "Base index ready.");
    Ok(())
}

fn stream_stage_base(cfg: &AppConfig, output_pool: &Pool, sig: &str, cursor: String, tx: &Sender<EngineEvent>, control: &EngineControl) -> Result<()> {
    let src_pool = db::pool(&cfg.source1)?;
    let mut last = cursor;
    loop {
        check_control(control)?;
        let rows = read_source_page(&src_pool, &cfg.source1, &cfg.source1_fields, &last, cfg.performance.exact_batch_size)?;
        if rows.is_empty() { break; }
        let next = rows.last().unwrap().row_key.clone();
        let mut out = output_pool.get_conn()?;
        out.query_drop("START TRANSACTION")?;
        insert_base_rows(&mut out, &rows)?;
        out.exec_drop(format!("UPDATE {} SET build_cursor=?,row_count=row_count+?,updated_at=NOW() WHERE id=1 AND base_signature=?", db::qident(BASE_REGISTRY)), (&next, rows.len() as u64, sig))?;
        out.query_drop("COMMIT")?;
        last = next;
        log(tx, format!("Base index streamed through source key {last}"));
    }
    let mut out = output_pool.get_conn()?;
    out.exec_drop(format!("UPDATE {} SET status='READY',built_at=NOW(),updated_at=NOW() WHERE id=1 AND base_signature=?", db::qident(BASE_REGISTRY)), (sig,))?;
    Ok(())
}

fn stage_input(job_id: &str, cfg: &AppConfig, output_pool: &Pool, tx: &Sender<EngineEvent>, control: &EngineControl) -> Result<()> {
    let (source, fields) = source_for_stage(cfg);
    let mut out = output_pool.get_conn()?;
    let cursor: Option<String> = out.exec_first(format!("SELECT stage_cursor FROM {} WHERE job_id=?", db::qident(JOBS_TABLE)), (job_id,))?;
    if cursor.as_deref() == Some("__DONE__") {
        log(tx, "Input staging already complete; resuming from matching checkpoint.");
        return Ok(());
    }
    let mut last = cursor.unwrap_or_default();
    drop(out);

    if can_fast_stage(source, &cfg.destination) {
        match fast_stage_input(job_id, cfg, output_pool, source, fields, last.clone(), tx, control) {
            Ok(()) => return Ok(()),
            Err(e) => log(tx, format!("Fast server-side input staging was unavailable ({e}). Falling back to Rust streaming.")),
        }
    }

    let src_pool = db::pool(source)?;
    loop {
        check_control(control)?;
        let rows = read_source_page(&src_pool, source, fields, &last, cfg.performance.exact_batch_size)?;
        if rows.is_empty() { break; }
        let next = rows.last().unwrap().row_key.clone();
        let mut c = output_pool.get_conn()?;
        c.query_drop("START TRANSACTION")?;
        insert_stage_rows(&mut c, job_id, &rows)?;
        // row_key is required to be a stable unique key; the insert and checkpoint are one transaction.
        // Using the page length avoids a 100M-row COUNT(*) at every staging checkpoint.
        let inserted = rows.len() as u64;
        c.exec_drop(format!("UPDATE {} SET stage_cursor=?,current_phase='STAGING',total_source_rows=total_source_rows+?,updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)), (&next, inserted, job_id))?;
        c.query_drop("COMMIT")?;
        last = next;
        log(tx, format!("Input stage checkpoint: source key {last}"));
    }
    let mut c = output_pool.get_conn()?;
    c.exec_drop(format!("UPDATE {} SET stage_cursor='__DONE__',current_phase='STAGED',updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)), (job_id,))?;
    log(tx, "Input staging complete.");
    Ok(())
}

fn fast_stage_input(job_id: &str, cfg: &AppConfig, output_pool: &Pool, source: &crate::model::DbConfig, fields: &crate::model::FieldMap, mut cursor: String, tx: &Sender<EngineEvent>, control: &EngineControl) -> Result<()> {
    let mut out = output_pool.get_conn()?;
    loop {
        check_control(control)?;
        let hi = match high_key(&mut out, source, &fields.row_key, &cursor, cfg.performance.exact_batch_size)? { Some(x) => x, None => break };
        let (row_key, person_id, first, middle, mi, last, dob, barangay, city) = normalized_select_sql(fields);
        let src = db::qtable(&source.database, &source.table);
        let stage = db::qident(STAGE_TABLE);
        let keycol = db::qident(&fields.row_key);
        let where_sql = if cursor.is_empty() { format!("{keycol}<=?") } else { format!("{keycol}>? AND {keycol}<=?") };
        let derived = format!(r#"SELECT {row_key} source_row_key,{person_id} source_record_id,{first} first_name,{middle} middle_name,{mi} middle_initial,{last} last_name,{dob} birthdate,{barangay} barangay_code,{city} city_code FROM {src} WHERE {where_sql}"#);
        let sql = format!(r#"INSERT IGNORE INTO {stage}(job_id,source_row_key,source_record_id,first_name,middle_name,middle_initial,last_name,birthdate,birth_year,birth_month,birth_day,barangay_code,city_code,first_initial,last_initial,first_prefix3,last_prefix3,key_l1,key_l2,key_l3,key_full_name)
            SELECT ?,source_row_key,source_record_id,first_name,middle_name,middle_initial,last_name,birthdate,YEAR(birthdate),MONTH(birthdate),DAY(birthdate),barangay_code,city_code,LEFT(first_name,1),LEFT(last_name,1),LEFT(first_name,3),LEFT(last_name,3),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,middle_name,last_name,COALESCE(DATE_FORMAT(birthdate,'%Y-%m-%d'),'')))),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,middle_initial,last_name,COALESCE(DATE_FORMAT(birthdate,'%Y-%m-%d'),'')))),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,last_name,COALESCE(DATE_FORMAT(birthdate,'%Y-%m-%d'),'')))),
            UNHEX(MD5(CONCAT_WS(CHAR(31),first_name,middle_name,last_name))) FROM ({derived}) s"#);
        out.query_drop("START TRANSACTION")?;
        let result = if cursor.is_empty() { out.exec_drop(&sql, (job_id, &hi)) } else { out.exec_drop(&sql, (job_id, &cursor, &hi)) };
        if let Err(e) = result { let _ = out.query_drop("ROLLBACK"); return Err(e.into()); }
        let inserted = out.affected_rows();
        cursor = hi;
        out.exec_drop(format!("UPDATE {} SET stage_cursor=?,current_phase='STAGING',total_source_rows=total_source_rows+?,updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)), (&cursor, inserted, job_id))?;
        out.query_drop("COMMIT")?;
        log(tx, format!("Input stage checkpoint: source key {cursor}"));
    }
    out.exec_drop(format!("UPDATE {} SET stage_cursor='__DONE__',current_phase='STAGED',updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)), (job_id,))?;
    Ok(())
}

fn read_source_page(pool: &Pool, source: &crate::model::DbConfig, fields: &crate::model::FieldMap, cursor: &str, limit: usize) -> Result<Vec<SourceRow>> {
    let mut c = pool.get_conn()?;
    let table = db::qtable(&source.database, &source.table);
    let k = db::qident(&fields.row_key);
    let p = db::qident(&fields.person_id);
    let f = db::qident(&fields.first_name);
    let m = db::qident(&fields.middle_name);
    let l = db::qident(&fields.last_name);
    let bd = db::qident(&fields.birthdate);
    let mi = if fields.middle_initial.trim().is_empty() { "''".to_string() } else { format!("COALESCE(CAST({} AS CHAR),'')", db::qident(&fields.middle_initial)) };
    let bg = if fields.barangay_code.trim().is_empty() { "''".into() } else { format!("COALESCE(CAST({} AS CHAR),'')", db::qident(&fields.barangay_code)) };
    let city = if fields.city_code.trim().is_empty() { "''".into() } else { format!("COALESCE(CAST({} AS CHAR),'')", db::qident(&fields.city_code)) };
    let select = format!("SELECT CAST({k} AS CHAR),COALESCE(CAST({p} AS CHAR),''),COALESCE(CAST({f} AS CHAR),''),COALESCE(CAST({m} AS CHAR),''),{mi},COALESCE(CAST({l} AS CHAR),''),COALESCE(DATE_FORMAT({bd},'%Y-%m-%d'),''),{bg},{city} FROM {table}");
    let sql = if cursor.is_empty() {
        format!("{select} ORDER BY {k} LIMIT {limit}")
    } else {
        format!("{select} WHERE {k}>? ORDER BY {k} LIMIT {limit}")
    };
    type T = (String, String, String, String, String, String, String, String, String);
    let raw: Vec<T> = if cursor.is_empty() { c.query(sql)? } else { c.exec(sql, (cursor,))? };
    Ok(raw.into_iter().map(|(row_key, person_id, first, middle, mi, last, dob, barangay, city)| SourceRow {
        row_key,
        person_id,
        first: normalize(&first),
        middle: normalize(&middle),
        mi: normalize_mi(&mi, &middle),
        last: normalize(&last),
        birthdate: crate::normalize::parse_date(&dob),
        barangay: normalize(&barangay),
        city: normalize(&city),
    }).collect())
}

fn insert_base_rows(c: &mut PooledConn, rows: &[SourceRow]) -> Result<()> {
    let sql = format!(r#"INSERT IGNORE INTO {}(source_row_key,person_id,first_name,middle_name,middle_initial,last_name,birthdate,birth_year,birth_month,birth_day,barangay_code,city_code,first_initial,last_initial,first_prefix3,last_prefix3,key_l1,key_l2,key_l3,key_full_name)
        VALUES(:row_key,:person_id,:first,:middle,:mi,:last,:dob,:y,:mo,:d,:barangay,:city,:fi,:li,:fp,:lp,:k1,:k2,:k3,:kf)"#, db::qident(BASE_TABLE));
    let params = rows.iter().map(|r| {
        let dob_s = r.birthdate.map(|d| d.format("%Y-%m-%d").to_string()).unwrap_or_default();
        let (y, mo, d) = r.birthdate.map(|x| (Some(x.year()), Some(x.month() as u8), Some(x.day() as u8))).unwrap_or((None, None, None));
        params! {
            "row_key" => &r.row_key, "person_id" => &r.person_id, "first" => &r.first, "middle" => &r.middle, "mi" => &r.mi, "last" => &r.last,
            "dob" => r.birthdate, "y" => y, "mo" => mo, "d" => d, "barangay" => &r.barangay, "city" => &r.city,
            "fi" => first_char(&r.first), "li" => first_char(&r.last), "fp" => prefix_chars(&r.first, 3), "lp" => prefix_chars(&r.last, 3),
            "k1" => md5_key(&[&r.first,&r.middle,&r.last,&dob_s]).to_vec(),
            "k2" => md5_key(&[&r.first,&r.mi,&r.last,&dob_s]).to_vec(),
            "k3" => md5_key(&[&r.first,&r.last,&dob_s]).to_vec(),
            "kf" => md5_key(&[&r.first,&r.middle,&r.last]).to_vec(),
        }
    });
    c.exec_batch(sql, params)?;
    Ok(())
}

fn insert_stage_rows(c: &mut PooledConn, job_id: &str, rows: &[SourceRow]) -> Result<()> {
    let sql = format!(r#"INSERT IGNORE INTO {}(job_id,source_row_key,source_record_id,first_name,middle_name,middle_initial,last_name,birthdate,birth_year,birth_month,birth_day,barangay_code,city_code,first_initial,last_initial,first_prefix3,last_prefix3,key_l1,key_l2,key_l3,key_full_name)
        VALUES(:job,:row_key,:person_id,:first,:middle,:mi,:last,:dob,:y,:mo,:d,:barangay,:city,:fi,:li,:fp,:lp,:k1,:k2,:k3,:kf)"#, db::qident(STAGE_TABLE));
    let params = rows.iter().map(|r| {
        let dob_s = r.birthdate.map(|d| d.format("%Y-%m-%d").to_string()).unwrap_or_default();
        let (y, mo, d) = r.birthdate.map(|x| (Some(x.year()), Some(x.month() as u8), Some(x.day() as u8))).unwrap_or((None, None, None));
        params! {
            "job" => job_id, "row_key" => &r.row_key, "person_id" => &r.person_id, "first" => &r.first, "middle" => &r.middle, "mi" => &r.mi, "last" => &r.last,
            "dob" => r.birthdate, "y" => y, "mo" => mo, "d" => d, "barangay" => &r.barangay, "city" => &r.city,
            "fi" => first_char(&r.first), "li" => first_char(&r.last), "fp" => prefix_chars(&r.first, 3), "lp" => prefix_chars(&r.last, 3),
            "k1" => md5_key(&[&r.first,&r.middle,&r.last,&dob_s]).to_vec(),
            "k2" => md5_key(&[&r.first,&r.mi,&r.last,&dob_s]).to_vec(),
            "k3" => md5_key(&[&r.first,&r.last,&dob_s]).to_vec(),
            "kf" => md5_key(&[&r.first,&r.middle,&r.last]).to_vec(),
        }
    });
    c.exec_batch(sql, params)?;
    Ok(())
}

fn ensure_level_progress(c: &mut PooledConn, job_id: &str, phase: &str, level: MatchLevel) -> Result<LevelProgress> {
    let row: Option<(String, u64)> = c.exec_first(
        format!("SELECT status,last_source_row_id FROM {} WHERE job_id=? AND phase=? AND level_name=?", db::qident(LEVEL_STATS_TABLE)),
        (job_id, phase, level.code()),
    )?;
    if let Some((status, cursor)) = row { return Ok(LevelProgress { status, cursor }); }
    c.exec_drop(
        format!("INSERT INTO {}(job_id,phase,level_name,status,last_source_row_id,started_at,updated_at) VALUES(?,?,?,'RUNNING',0,NOW(),NOW())", db::qident(LEVEL_STATS_TABLE)),
        (job_id, phase, level.code()),
    )?;
    Ok(LevelProgress { status: "RUNNING".into(), cursor: 0 })
}

fn update_level_progress(c: &mut PooledConn, job_id: &str, phase: &str, level: MatchLevel, cursor: u64, eligible: u64, matched: u64, ambiguous: u64, candidates: u64, elapsed: f64, status: &str) -> Result<()> {
    c.exec_drop(
        format!(r#"UPDATE {} SET status=?,last_source_row_id=?,eligible=eligible+?,matched=matched+?,ambiguous=ambiguous+?,candidates=candidates+?,duration_seconds=duration_seconds+?,finished_at=IF(?='DONE',NOW(),finished_at),updated_at=NOW() WHERE job_id=? AND phase=? AND level_name=?"#, db::qident(LEVEL_STATS_TABLE)),
        (status, cursor, eligible, matched, ambiguous, candidates, elapsed, status, job_id, phase, level.code()),
    )?;
    // processed/matched counters are maintained incrementally per committed batch.
    // Avoid scanning the growing stage table at every level checkpoint.
    c.exec_drop(
        format!("UPDATE {} SET current_phase=?,current_level=?,updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)),
        (phase, level.code(), job_id),
    )?;
    Ok(())
}

fn next_stage_range(c: &mut PooledConn, job_id: &str, cursor: u64, limit: usize, require_match_pending: bool) -> Result<Option<(u64,u64,u64)>> {
    let filter = if require_match_pending { "AND match_eligible=1 AND match_state='PENDING'" } else { "AND dedup_root_id IS NULL" };
    let sql = format!("SELECT MIN(source_row_id),MAX(source_row_id),COUNT(*) FROM (SELECT source_row_id FROM {} WHERE job_id=? AND source_row_id>? {filter} ORDER BY source_row_id LIMIT {limit}) x", db::qident(STAGE_TABLE));
    let r: Option<(Option<u64>,Option<u64>,u64)> = c.exec_first(sql, (job_id,cursor))?;
    Ok(r.and_then(|(lo,hi,count)| if count>0 { Some((lo.unwrap(),hi.unwrap(),count)) } else { None }))
}

fn exact_condition(level: MatchLevel) -> Result<(&'static str, &'static str)> {
    // Names in this SQL are normalized stage/base columns. Suffix/extension is intentionally absent.
    let out = match level {
        MatchLevel::L01 => ("b.key_l1=t.key_l1 AND b.first_name=t.first_name AND b.middle_name<>'' AND t.middle_name<>'' AND b.middle_name=t.middle_name AND b.last_name=t.last_name AND b.birthdate=t.birthdate AND t.first_name<>'' AND t.last_name<>''", "EXACT"),
        MatchLevel::L02 => ("b.key_l2=t.key_l2 AND b.first_name=t.first_name AND b.middle_initial=t.middle_initial AND b.middle_initial<>'' AND b.last_name=t.last_name AND b.birthdate=t.birthdate AND (b.middle_name=t.middle_name OR CHAR_LENGTH(b.middle_name)<=1 OR CHAR_LENGTH(t.middle_name)<=1) AND t.first_name<>'' AND t.last_name<>''", "EXACT_MI"),
        MatchLevel::L03 => ("b.key_l3=t.key_l3 AND b.first_name=t.first_name AND b.last_name=t.last_name AND b.birthdate=t.birthdate AND (b.middle_name='' OR t.middle_name='' OR b.middle_name=t.middle_name OR (b.middle_initial=t.middle_initial AND b.middle_initial<>'' AND (CHAR_LENGTH(b.middle_name)<=1 OR CHAR_LENGTH(t.middle_name)<=1))) AND t.first_name<>'' AND t.last_name<>''", "EXACT_NO_MIDDLE"),
        MatchLevel::L04 => ("b.key_full_name=t.key_full_name AND b.first_name=t.first_name AND b.middle_name<>'' AND t.middle_name<>'' AND b.middle_name=t.middle_name AND b.last_name=t.last_name AND b.birthdate<>t.birthdate AND b.birth_year BETWEEN t.birth_year-5 AND t.birth_year+5 AND b.birth_month BETWEEN t.birth_month-3 AND t.birth_month+3 AND b.birth_day BETWEEN t.birth_day-3 AND t.birth_day+3 AND t.first_name<>'' AND t.last_name<>''", "EXACT_NEAR_DOB"),
        MatchLevel::L08 => ("b.first_name=t.last_name AND b.middle_name=t.middle_name AND b.last_name=t.first_name AND b.birthdate=t.birthdate AND t.first_name<>'' AND t.last_name<>''", "SWAP"),
        MatchLevel::L09 => ("b.first_name=t.first_name AND b.middle_name=t.last_name AND b.last_name=t.middle_name AND b.birthdate=t.birthdate AND t.first_name<>'' AND t.last_name<>''", "SWAP"),
        MatchLevel::L10 => ("b.first_name=t.middle_name AND b.middle_name=t.first_name AND b.last_name=t.last_name AND b.birthdate=t.birthdate AND t.first_name<>'' AND t.last_name<>''", "SWAP"),
        MatchLevel::L11 => ("b.person_id=t.source_record_id AND b.first_name=t.first_name AND b.last_name=t.last_name AND t.source_record_id<>''", "COMMON_ID"),
        MatchLevel::L12 => ("t.barangay_code<>'' AND b.barangay_code=t.barangay_code AND b.first_name=t.first_name AND b.middle_name=t.middle_name AND b.last_name=t.last_name AND t.first_name<>'' AND t.last_name<>''", "GEO_BARANGAY"),
        MatchLevel::L13 => ("t.barangay_code<>'' AND b.barangay_code=t.barangay_code AND b.first_name=t.first_name AND b.middle_initial=t.middle_initial AND b.middle_initial<>'' AND b.last_name=t.last_name AND (b.middle_name=t.middle_name OR CHAR_LENGTH(b.middle_name)<=1 OR CHAR_LENGTH(t.middle_name)<=1) AND t.first_name<>'' AND t.last_name<>''", "GEO_BARANGAY"),
        MatchLevel::L14 => ("t.barangay_code<>'' AND b.barangay_code=t.barangay_code AND b.first_name=t.first_name AND b.last_name=t.last_name AND (b.middle_name='' OR t.middle_name='' OR b.middle_name=t.middle_name OR (b.middle_initial=t.middle_initial AND b.middle_initial<>'' AND (CHAR_LENGTH(b.middle_name)<=1 OR CHAR_LENGTH(t.middle_name)<=1))) AND t.first_name<>'' AND t.last_name<>''", "GEO_BARANGAY"),
        MatchLevel::L16 => ("t.city_code<>'' AND b.city_code=t.city_code AND b.first_name=t.first_name AND b.middle_initial=t.middle_initial AND b.middle_initial<>'' AND b.last_name=t.last_name AND (b.middle_name=t.middle_name OR CHAR_LENGTH(b.middle_name)<=1 OR CHAR_LENGTH(t.middle_name)<=1) AND t.first_name<>'' AND t.last_name<>''", "GEO_CITY"),
        MatchLevel::L17 => ("t.city_code<>'' AND b.city_code=t.city_code AND b.first_name=t.first_name AND b.last_name=t.last_name AND (b.middle_name='' OR t.middle_name='' OR b.middle_name=t.middle_name OR (b.middle_initial=t.middle_initial AND b.middle_initial<>'' AND (CHAR_LENGTH(b.middle_name)<=1 OR CHAR_LENGTH(t.middle_name)<=1))) AND t.first_name<>'' AND t.last_name<>''", "GEO_CITY"),
        _ => bail!("{} is not an exact/deterministic level", level.code()),
    };
    Ok(out)
}

fn run_name_matching(job_id: &str, cfg: &AppConfig, output_pool: &Pool, tx: &Sender<EngineEvent>, control: &EngineControl, similarity: &mut SimilarityEngine) -> Result<()> {
    log(tx, "Phase 1: selected exact/deterministic levels.");
    for level in cfg.exact_plan() {
        check_control(control)?;
        run_exact_level(job_id, cfg, output_pool, level, tx, control, similarity)?;
    }
    log(tx, "Phase 2: residual selected fuzzy levels only.");
    let mut governor = ResourceGovernor::new(cfg.performance.clone());
    for level in cfg.fuzzy_plan() {
        check_control(control)?;
        run_fuzzy_level(job_id, cfg, output_pool, level, tx, control, similarity, &mut governor)?;
    }
    Ok(())
}

fn run_exact_level(job_id: &str, cfg: &AppConfig, pool: &Pool, level: MatchLevel, tx: &Sender<EngineEvent>, control: &EngineControl, similarity: &SimilarityEngine) -> Result<()> {
    let (condition, category) = exact_condition(level)?;
    let mut c = pool.get_conn()?;
    let p = ensure_level_progress(&mut c, job_id, "MATCH_EXACT", level)?;
    if p.status == "DONE" { log(tx, format!("{} already complete; skipped.", level.code())); return Ok(()); }
    let mut cursor = p.cursor;
    drop(c);

    loop {
        check_control(control)?;
        let mut c = pool.get_conn()?;
        let Some((lo,hi,eligible)) = next_stage_range(&mut c, job_id, cursor, cfg.performance.exact_batch_size, true)? else { break; };
        let started = Instant::now();
        let sql = format!(r#"WITH ranked AS (
            SELECT t.source_row_id,COALESCE(t.source_record_id,''),b.base_row_id,COALESCE(b.person_id,''),
                   COUNT(*) OVER(PARTITION BY t.source_row_id) candidate_count,
                   ROW_NUMBER() OVER(PARTITION BY t.source_row_id ORDER BY b.base_row_id) rn
            FROM {stage} t JOIN {base} b ON {condition}
            WHERE t.job_id=? AND t.source_row_id BETWEEN ? AND ? AND t.match_eligible=1 AND t.match_state='PENDING')
            SELECT source_row_id,source_record_id,base_row_id,person_id,candidate_count FROM ranked WHERE rn=1"#,
            stage=db::qident(STAGE_TABLE), base=db::qident(BASE_TABLE));
        let decisions: Vec<ExactDecision> = c.exec_map(sql, (job_id,lo,hi), |(source_row_id,source_record_id,base_row_id,base_record_id,candidate_count): (u64,String,u64,String,u64)| ExactDecision { source_row_id,source_record_id,base_row_id,base_record_id,candidate_count })?;
        let matched = decisions.iter().filter(|x| x.candidate_count==1).count() as u64;
        let ambiguous = decisions.iter().filter(|x| x.candidate_count>1).count() as u64;
        let candidates = decisions.iter().map(|x| x.candidate_count).sum::<u64>();

        c.query_drop("START TRANSACTION")?;
        let result = (|| -> Result<()> {
            let insert_sql = format!(r#"INSERT INTO {}(job_id,source_row_id,source_record_id,base_row_id,base_record_id,match_status,matched_category,matched_level,final_score,candidate_count,middle_match_type,result_origin)
                VALUES(:job,:source,:source_id,:base,:base_id,'MATCHED',:category,:level,100.0,:cnt,'EXACT','DIRECT')
                ON DUPLICATE KEY UPDATE base_row_id=VALUES(base_row_id),base_record_id=VALUES(base_record_id),match_status='MATCHED',matched_category=VALUES(matched_category),matched_level=VALUES(matched_level),final_score=100.0,candidate_count=VALUES(candidate_count),result_origin='DIRECT'"#, db::qident(RESULTS_TABLE));
            let matched_params = decisions.iter().filter(|x| x.candidate_count==1).map(|x| params! {
                "job"=>job_id,"source"=>x.source_row_id,"source_id"=>&x.source_record_id,"base"=>x.base_row_id,"base_id"=>&x.base_record_id,
                "category"=>category,"level"=>level.code(),"cnt"=>x.candidate_count,
            });
            c.exec_batch(&insert_sql, matched_params)?;
            let matched_ids = decisions.iter().filter(|x| x.candidate_count==1).map(|x| params!{"job"=>job_id,"id"=>x.source_row_id});
            c.exec_batch(format!("UPDATE {} SET match_state='MATCHED' WHERE job_id=:job AND source_row_id=:id AND match_state='PENDING'", db::qident(STAGE_TABLE)), matched_ids)?;
            let amb_params = decisions.iter().filter(|x| x.candidate_count>1).map(|x| params!{"job"=>job_id,"id"=>x.source_row_id,"level"=>level.code()});
            c.exec_batch(format!("UPDATE {} SET match_ambiguous_level=COALESCE(match_ambiguous_level,:level),match_ambiguous_reason=COALESCE(match_ambiguous_reason,'MULTIPLE_EXACT') WHERE job_id=:job AND source_row_id=:id AND match_state='PENDING'", db::qident(STAGE_TABLE)), amb_params)?;
            let elapsed = started.elapsed().as_secs_f64();
            update_level_progress(&mut c,job_id,"MATCH_EXACT",level,hi,eligible,matched,ambiguous,candidates,elapsed,"RUNNING")?;
            increment_match_counters(&mut c, job_id, matched, candidates)?;
            Ok(())
        })();
        match result { Ok(()) => c.query_drop("COMMIT")?, Err(e) => { let _=c.query_drop("ROLLBACK"); return Err(e); } }
        cursor=hi;
        log(tx, format!("{} | eligible {} | matched {} | ambiguous {}", level.code(), fmt_u64(eligible), fmt_u64(matched), fmt_u64(ambiguous)));
        publish_snapshot(job_id,pool,similarity,tx)?;
    }
    let mut c=pool.get_conn()?;
    update_level_progress(&mut c,job_id,"MATCH_EXACT",level,cursor,0,0,0,0,0.0,"DONE")?;
    Ok(())
}

fn fuzzy_candidate_sql(level: MatchLevel, cap: usize) -> Result<String> {
    let block = match level {
        MatchLevel::L05 | MatchLevel::L06 => r#"b.birthdate=t.birthdate AND t.birthdate IS NOT NULL AND (
            (t.last_prefix3<>'' AND t.first_initial<>'' AND b.last_prefix3=t.last_prefix3 AND b.first_initial=t.first_initial)
            OR (t.first_prefix3<>'' AND t.last_initial<>'' AND b.first_prefix3=t.first_prefix3 AND b.last_initial=t.last_initial))"#,
        MatchLevel::L07 => r#"b.birthdate IS NOT NULL AND t.birthdate IS NOT NULL
            AND b.birth_year BETWEEN t.birth_year-5 AND t.birth_year+5
            AND b.birth_month BETWEEN t.birth_month-3 AND t.birth_month+3
            AND b.birth_day BETWEEN t.birth_day-3 AND t.birth_day+3
            AND ((t.last_prefix3<>'' AND t.first_initial<>'' AND b.last_prefix3=t.last_prefix3 AND b.first_initial=t.first_initial)
              OR (t.first_prefix3<>'' AND t.last_initial<>'' AND b.first_prefix3=t.first_prefix3 AND b.last_initial=t.last_initial))"#,
        MatchLevel::L15 => r#"t.city_code<>'' AND b.city_code=t.city_code AND (
            (t.last_prefix3<>'' AND t.first_initial<>'' AND b.last_prefix3=t.last_prefix3 AND b.first_initial=t.first_initial)
            OR (t.first_prefix3<>'' AND t.last_initial<>'' AND b.first_prefix3=t.first_prefix3 AND b.last_initial=t.last_initial))"#,
        _ => bail!("{} is not a fuzzy level", level.code()),
    };
    Ok(format!(r#"WITH raw AS (
        SELECT t.source_row_id,COALESCE(t.source_record_id,'') source_record_id,b.base_row_id,COALESCE(b.person_id,'') base_record_id,
               t.first_name source_first_name,t.middle_name source_middle_name,t.last_name source_last_name,
               b.first_name base_first_name,b.middle_name base_middle_name,b.last_name base_last_name,
               ROW_NUMBER() OVER(PARTITION BY t.source_row_id ORDER BY (b.last_name=t.last_name) DESC,(b.first_name=t.first_name) DESC,b.base_row_id) rn,
               COUNT(*) OVER(PARTITION BY t.source_row_id) candidate_pool_count
        FROM {stage} t JOIN {base} b ON {block}
        WHERE t.job_id=? AND t.source_row_id BETWEEN ? AND ? AND t.match_eligible=1 AND t.match_state='PENDING'
          AND t.first_name<>'' AND t.last_name<>'')
        SELECT source_row_id,source_record_id,base_row_id,base_record_id,source_first_name,source_middle_name,source_last_name,
               base_first_name,base_middle_name,base_last_name,candidate_pool_count
        FROM raw WHERE rn<={cap} ORDER BY source_row_id,rn"#,
        stage=db::qident(STAGE_TABLE),base=db::qident(BASE_TABLE)))
}

fn run_fuzzy_level(job_id: &str, cfg: &AppConfig, pool: &Pool, level: MatchLevel, tx: &Sender<EngineEvent>, control: &EngineControl, similarity: &mut SimilarityEngine, governor: &mut ResourceGovernor) -> Result<()> {
    let mut c=pool.get_conn()?;
    let p=ensure_level_progress(&mut c,job_id,"MATCH_FUZZY",level)?;
    if p.status=="DONE" { log(tx,format!("{} already complete; skipped.",level.code())); return Ok(()); }
    let mut cursor=p.cursor;
    drop(c);
    let sql=fuzzy_candidate_sql(level,cfg.performance.fuzzy_candidate_cap)?;

    loop {
        check_control(control)?;
        let chunk=governor.fuzzy_source_chunk();
        let mut c=pool.get_conn()?;
        let Some((lo,hi,eligible))=next_stage_range(&mut c,job_id,cursor,chunk,true)? else { break; };
        let started=Instant::now();
        let raw: Vec<(u64,String,u64,String,String,String,String,String,String,String,u64)> = c.exec(&sql,(job_id,lo,hi))?;
        let candidates: Vec<Candidate> = raw.into_iter().map(|r| Candidate {
            source_row_id:r.0,source_record_id:r.1,base_row_id:r.2,base_record_id:r.3,
            source_first_name:r.4,source_middle_name:r.5,source_last_name:r.6,
            base_first_name:r.7,base_middle_name:r.8,base_last_name:r.9,candidate_pool_count:r.10.min(u32::MAX as u64) as u32,
        }).collect();
        let mut pool_counts: HashMap<u64,u32>=HashMap::new();
        for x in &candidates { pool_counts.entry(x.source_row_id).and_modify(|v|*v=(*v).max(x.candidate_pool_count)).or_insert(x.candidate_pool_count); }
        let candidate_rows=candidates.len() as u64;
        let decisions=similarity.score_candidates(level,candidates,&cfg.thresholds,cfg.performance.fuzzy_candidate_cap);
        let decided: std::collections::HashSet<u64>=decisions.iter().map(|x|x.source_row_id).collect();
        let capped_without_accept: Vec<u64>=pool_counts.iter().filter(|(id,count)| **count as usize>cfg.performance.fuzzy_candidate_cap && !decided.contains(id)).map(|(id,_)|*id).collect();
        let matched=decisions.iter().filter(|x|!x.ambiguous).count() as u64;
        let ambiguous=decisions.iter().filter(|x|x.ambiguous).count() as u64 + capped_without_accept.len() as u64;

        c.query_drop("START TRANSACTION")?;
        let result=(||->Result<()> {
            let insert_sql=format!(r#"INSERT INTO {}(job_id,source_row_id,source_record_id,base_row_id,base_record_id,match_status,matched_category,matched_level,final_score,first_name_score,middle_name_score,last_name_score,candidate_count,second_best_score,score_margin,middle_match_type,ambiguity_reason,result_origin)
                VALUES(:job,:source,:source_id,:base,:base_id,'MATCHED','FUZZY',:level,:final,:fn,:mn,:ln,:cnt,:second,:margin,:middle,NULL,'DIRECT')
                ON DUPLICATE KEY UPDATE base_row_id=VALUES(base_row_id),base_record_id=VALUES(base_record_id),match_status='MATCHED',matched_category='FUZZY',matched_level=VALUES(matched_level),final_score=VALUES(final_score),first_name_score=VALUES(first_name_score),middle_name_score=VALUES(middle_name_score),last_name_score=VALUES(last_name_score),candidate_count=VALUES(candidate_count),second_best_score=VALUES(second_best_score),score_margin=VALUES(score_margin),middle_match_type=VALUES(middle_match_type),ambiguity_reason=NULL,result_origin='DIRECT'"#,db::qident(RESULTS_TABLE));
            let matched_params=decisions.iter().filter(|x|!x.ambiguous).map(|x| params!{
                "job"=>job_id,"source"=>x.source_row_id,"source_id"=>&x.source_record_id,"base"=>x.base_row_id,"base_id"=>&x.base_record_id,"level"=>level.code(),
                "final"=>x.final_score,"fn"=>x.first_name_score,"mn"=>x.middle_name_score,"ln"=>x.last_name_score,"cnt"=>x.candidate_count,
                "second"=>x.second_best_score,"margin"=>x.score_margin,"middle"=>&x.middle_match_type,
            });
            c.exec_batch(&insert_sql,matched_params)?;
            let matched_ids=decisions.iter().filter(|x|!x.ambiguous).map(|x|params!{"job"=>job_id,"id"=>x.source_row_id});
            c.exec_batch(format!("UPDATE {} SET match_state='MATCHED' WHERE job_id=:job AND source_row_id=:id AND match_state='PENDING'",db::qident(STAGE_TABLE)),matched_ids)?;
            let amb_params=decisions.iter().filter(|x|x.ambiguous).map(|x|params!{"job"=>job_id,"id"=>x.source_row_id,"level"=>level.code(),"reason"=>x.ambiguity_reason.clone().unwrap_or_else(||"SCORE_MARGIN".into())});
            c.exec_batch(format!("UPDATE {} SET match_ambiguous_level=COALESCE(match_ambiguous_level,:level),match_ambiguous_reason=COALESCE(match_ambiguous_reason,:reason) WHERE job_id=:job AND source_row_id=:id AND match_state='PENDING'",db::qident(STAGE_TABLE)),amb_params)?;
            let cap_params=capped_without_accept.iter().map(|id|params!{"job"=>job_id,"id"=>*id,"level"=>level.code()});
            c.exec_batch(format!("UPDATE {} SET match_ambiguous_level=COALESCE(match_ambiguous_level,:level),match_ambiguous_reason=COALESCE(match_ambiguous_reason,'CANDIDATE_CAP') WHERE job_id=:job AND source_row_id=:id AND match_state='PENDING'",db::qident(STAGE_TABLE)),cap_params)?;
            let elapsed=started.elapsed().as_secs_f64();
            update_level_progress(&mut c,job_id,"MATCH_FUZZY",level,hi,eligible,matched,ambiguous,candidate_rows,elapsed,"RUNNING")?;
            increment_match_counters(&mut c, job_id, matched, candidate_rows)?;
            Ok(())
        })();
        match result {Ok(())=>c.query_drop("COMMIT")?,Err(e)=>{let _=c.query_drop("ROLLBACK");return Err(e);}}
        cursor=hi;
        log(tx,format!("{} | source {} | candidates {} | matched {} | ambiguous {} | GPU {}", level.code(), fmt_u64(eligible), fmt_u64(candidate_rows), fmt_u64(matched), fmt_u64(ambiguous), if similarity.gpu_active { "ON" } else { "OFF" }));
        publish_snapshot(job_id,pool,similarity,tx)?;
    }
    let mut c=pool.get_conn()?;
    update_level_progress(&mut c,job_id,"MATCH_FUZZY",level,cursor,0,0,0,0,0.0,"DONE")?;
    Ok(())
}

fn run_dedup(job_id: &str, cfg: &AppConfig, pool: &Pool, tx: &Sender<EngineEvent>, control: &EngineControl, similarity: &mut SimilarityEngine) -> Result<()> {
    log(tx,"Deduplication uses selected core Levels 1–7 only. Advanced Levels 8–17 do not apply to deduplication.");
    for level in [MatchLevel::L01,MatchLevel::L02,MatchLevel::L03,MatchLevel::L04] {
        if cfg.selected(level) {
            run_dedup_exact_level(job_id,cfg,pool,level,tx,control,similarity)?;
        }
    }
    let mut governor=ResourceGovernor::new(cfg.performance.clone());
    for level in [MatchLevel::L05,MatchLevel::L06,MatchLevel::L07] {
        if cfg.selected(level) {
            run_dedup_fuzzy_level(job_id,cfg,pool,level,tx,control,similarity,&mut governor)?;
        }
    }
    resolve_dedup_roots(job_id,pool)?;
    materialize_dedup(job_id,pool)?;
    apply_consolidation(job_id,cfg,pool)?;
    let mut c=pool.get_conn()?;
    update_job_counters(&mut c,job_id)?;
    Ok(())
}

fn run_dedup_exact_level(job_id:&str,cfg:&AppConfig,pool:&Pool,level:MatchLevel,tx:&Sender<EngineEvent>,control:&EngineControl,similarity:&SimilarityEngine)->Result<()> {
    let (condition,_)=exact_condition(level)?;
    let mut c=pool.get_conn()?;
    let p=ensure_level_progress(&mut c,job_id,"DEDUP_EXACT",level)?;
    if p.status=="DONE" {return Ok(());}
    let mut cursor=p.cursor;
    drop(c);
    loop {
        check_control(control)?;
        let mut c=pool.get_conn()?;
        let Some((lo,hi,eligible))=next_stage_range(&mut c,job_id,cursor,cfg.performance.exact_batch_size,false)? else {break;};
        let started=Instant::now();
        let sql=format!(r#"SELECT t.source_row_id,MIN(b.source_row_id) root_id,COUNT(*) candidate_count
            FROM {stage} t JOIN {stage} b ON b.job_id=t.job_id AND b.source_row_id<t.source_row_id AND b.dedup_root_id IS NULL AND {condition}
            WHERE t.job_id=? AND t.source_row_id BETWEEN ? AND ? AND t.dedup_root_id IS NULL
            GROUP BY t.source_row_id"#,stage=db::qident(STAGE_TABLE));
        let rows:Vec<(u64,u64,u64)>=c.exec(sql,(job_id,lo,hi))?;
        let matched=rows.len() as u64;
        c.query_drop("START TRANSACTION")?;
        let result=(||->Result<()> {
            let confidence=if matches!(level,MatchLevel::L01|MatchLevel::L02|MatchLevel::L03){"CONFIRMED"}else{"HIGH_PROBABILITY"};
            let ps=rows.iter().map(|(source,root,_)|params!{"job"=>job_id,"source"=>*source,"root"=>*root,"level"=>level.code(),"confidence"=>confidence});
            c.exec_batch(format!("UPDATE {} SET dedup_root_id=:root,dedup_level=:level,dedup_confidence=:confidence WHERE job_id=:job AND source_row_id=:source AND dedup_root_id IS NULL",db::qident(STAGE_TABLE)),ps)?;
            resolve_dedup_roots_with_conn(job_id,&mut c)?;
            update_level_progress(&mut c,job_id,"DEDUP_EXACT",level,hi,eligible,matched,0,rows.iter().map(|x|x.2).sum(),started.elapsed().as_secs_f64(),"RUNNING")?;
            Ok(())
        })();
        match result {Ok(())=>c.query_drop("COMMIT")?,Err(e)=>{let _=c.query_drop("ROLLBACK");return Err(e);}}
        cursor=hi;
        log(tx,format!("Dedup {} | examined {} | duplicates {}", level.code(), fmt_u64(eligible), fmt_u64(matched)));
        publish_snapshot(job_id,pool,similarity,tx)?;
    }
    let mut c=pool.get_conn()?;
    update_level_progress(&mut c,job_id,"DEDUP_EXACT",level,cursor,0,0,0,0,0.0,"DONE")?;
    Ok(())
}

fn dedup_fuzzy_sql(level:MatchLevel,cap:usize)->Result<String>{
    let block=match level{
        MatchLevel::L05|MatchLevel::L06=>r#"b.birthdate=t.birthdate AND t.birthdate IS NOT NULL AND (
            (t.last_prefix3<>'' AND t.first_initial<>'' AND b.last_prefix3=t.last_prefix3 AND b.first_initial=t.first_initial)
            OR (t.first_prefix3<>'' AND t.last_initial<>'' AND b.first_prefix3=t.first_prefix3 AND b.last_initial=t.last_initial))"#,
        MatchLevel::L07=>r#"b.birthdate IS NOT NULL AND t.birthdate IS NOT NULL
            AND b.birth_year BETWEEN t.birth_year-5 AND t.birth_year+5
            AND b.birth_month BETWEEN t.birth_month-3 AND t.birth_month+3
            AND b.birth_day BETWEEN t.birth_day-3 AND t.birth_day+3
            AND ((t.last_prefix3<>'' AND t.first_initial<>'' AND b.last_prefix3=t.last_prefix3 AND b.first_initial=t.first_initial)
              OR (t.first_prefix3<>'' AND t.last_initial<>'' AND b.first_prefix3=t.first_prefix3 AND b.last_initial=t.last_initial))"#,
        _=>bail!("Dedup fuzzy only supports L5-L7"),
    };
    Ok(format!(r#"WITH raw AS (
        SELECT t.source_row_id,COALESCE(t.source_record_id,'') source_record_id,b.source_row_id base_row_id,COALESCE(b.source_record_id,'') base_record_id,
               t.first_name source_first_name,t.middle_name source_middle_name,t.last_name source_last_name,
               b.first_name base_first_name,b.middle_name base_middle_name,b.last_name base_last_name,
               ROW_NUMBER() OVER(PARTITION BY t.source_row_id ORDER BY (b.last_name=t.last_name) DESC,(b.first_name=t.first_name) DESC,b.source_row_id) rn,
               COUNT(*) OVER(PARTITION BY t.source_row_id) candidate_pool_count
        FROM {stage} t JOIN {stage} b ON b.job_id=t.job_id AND b.source_row_id<t.source_row_id AND b.dedup_root_id IS NULL AND {block}
        WHERE t.job_id=? AND t.source_row_id BETWEEN ? AND ? AND t.dedup_root_id IS NULL AND t.first_name<>'' AND t.last_name<>'')
        SELECT source_row_id,source_record_id,base_row_id,base_record_id,source_first_name,source_middle_name,source_last_name,
               base_first_name,base_middle_name,base_last_name,candidate_pool_count
        FROM raw WHERE rn<={cap} ORDER BY source_row_id,rn"#,stage=db::qident(STAGE_TABLE)))
}

fn run_dedup_fuzzy_level(job_id:&str,cfg:&AppConfig,pool:&Pool,level:MatchLevel,tx:&Sender<EngineEvent>,control:&EngineControl,similarity:&mut SimilarityEngine,governor:&mut ResourceGovernor)->Result<()> {
    let mut c=pool.get_conn()?;
    let p=ensure_level_progress(&mut c,job_id,"DEDUP_FUZZY",level)?;
    if p.status=="DONE" {return Ok(());}
    let mut cursor=p.cursor;
    drop(c);
    let sql=dedup_fuzzy_sql(level,cfg.performance.fuzzy_candidate_cap)?;
    loop {
        check_control(control)?;
        let chunk=governor.fuzzy_source_chunk();
        let mut c=pool.get_conn()?;
        let Some((lo,hi,eligible))=next_stage_range(&mut c,job_id,cursor,chunk,false)? else {break;};
        let started=Instant::now();
        let raw:Vec<(u64,String,u64,String,String,String,String,String,String,String,u64)>=c.exec(&sql,(job_id,lo,hi))?;
        let candidates:Vec<Candidate>=raw.into_iter().map(|r|Candidate{source_row_id:r.0,source_record_id:r.1,base_row_id:r.2,base_record_id:r.3,source_first_name:r.4,source_middle_name:r.5,source_last_name:r.6,base_first_name:r.7,base_middle_name:r.8,base_last_name:r.9,candidate_pool_count:r.10.min(u32::MAX as u64) as u32}).collect();
        let candidate_rows=candidates.len() as u64;
        let decisions=similarity.score_candidates(level,candidates,&cfg.thresholds,cfg.performance.fuzzy_candidate_cap);
        let matched=decisions.iter().filter(|x|!x.ambiguous).count() as u64;
        let ambiguous=decisions.iter().filter(|x|x.ambiguous).count() as u64;
        c.query_drop("START TRANSACTION")?;
        let result=(||->Result<()> {
            let good=decisions.iter().filter(|x|!x.ambiguous).map(|x|params!{"job"=>job_id,"source"=>x.source_row_id,"root"=>x.base_row_id,"level"=>level.code()});
            c.exec_batch(format!("UPDATE {} SET dedup_root_id=:root,dedup_level=:level,dedup_confidence='HIGH_PROBABILITY' WHERE job_id=:job AND source_row_id=:source AND dedup_root_id IS NULL",db::qident(STAGE_TABLE)),good)?;
            let amb=decisions.iter().filter(|x|x.ambiguous).map(|x|params!{"job"=>job_id,"source"=>x.source_row_id,"reason"=>x.ambiguity_reason.clone().unwrap_or_else(||"SCORE_MARGIN".into())});
            c.exec_batch(format!("UPDATE {} SET dedup_ambiguous_reason=COALESCE(dedup_ambiguous_reason,:reason) WHERE job_id=:job AND source_row_id=:source AND dedup_root_id IS NULL",db::qident(STAGE_TABLE)),amb)?;
            resolve_dedup_roots_with_conn(job_id,&mut c)?;
            update_level_progress(&mut c,job_id,"DEDUP_FUZZY",level,hi,eligible,matched,ambiguous,candidate_rows,started.elapsed().as_secs_f64(),"RUNNING")?;
            Ok(())
        })();
        match result {Ok(())=>c.query_drop("COMMIT")?,Err(e)=>{let _=c.query_drop("ROLLBACK");return Err(e);}}
        cursor=hi;
        log(tx,format!("Dedup {} | candidates {} | duplicates {} | ambiguous {}", level.code(), fmt_u64(candidate_rows), fmt_u64(matched), fmt_u64(ambiguous)));
        publish_snapshot(job_id,pool,similarity,tx)?;
    }
    let mut c=pool.get_conn()?;
    update_level_progress(&mut c,job_id,"DEDUP_FUZZY",level,cursor,0,0,0,0,0.0,"DONE")?;
    Ok(())
}

fn resolve_dedup_roots(job_id:&str,pool:&Pool)->Result<()> { let mut c=pool.get_conn()?; resolve_dedup_roots_with_conn(job_id,&mut c) }

fn resolve_dedup_roots_with_conn(job_id:&str,c:&mut PooledConn)->Result<()> {
    for _ in 0..32 {
        c.exec_drop(format!(r#"UPDATE {stage} s JOIN {stage} p ON p.job_id=s.job_id AND p.source_row_id=s.dedup_root_id
            SET s.dedup_root_id=p.dedup_root_id
            WHERE s.job_id=? AND s.dedup_root_id IS NOT NULL AND p.dedup_root_id IS NOT NULL AND s.dedup_root_id<>p.dedup_root_id"#,stage=db::qident(STAGE_TABLE)),(job_id,))?;
        if c.affected_rows()==0 {break;}
    }
    Ok(())
}

fn materialize_dedup(job_id:&str,pool:&Pool)->Result<()> {
    let mut c=pool.get_conn()?;
    c.exec_drop(format!(r#"INSERT INTO {dedup}(job_id,source_row_id,duplicate_of_source_row_id,dedup_level,dedup_score,confidence,middle_match_type)
        SELECT job_id,source_row_id,dedup_root_id,dedup_level,IF(dedup_level IN ('L1','L2','L3','L4'),100.0,NULL),COALESCE(dedup_confidence,'HIGH_PROBABILITY'),NULL
        FROM {stage} WHERE job_id=? AND dedup_root_id IS NOT NULL
        ON DUPLICATE KEY UPDATE duplicate_of_source_row_id=VALUES(duplicate_of_source_row_id),dedup_level=VALUES(dedup_level),confidence=VALUES(confidence)"#,dedup=db::qident(DEDUP_TABLE),stage=db::qident(STAGE_TABLE)),(job_id,))?;
    Ok(())
}

fn apply_consolidation(job_id:&str,cfg:&AppConfig,pool:&Pool)->Result<()> {
    let mut c=pool.get_conn()?;
    if matches!(cfg.mode,ProcessMode::DedupConsolidateMatch) {
        match cfg.consolidation {
            ConsolidationMode::ExactOnly=>c.exec_drop(format!("UPDATE {} SET match_eligible=IF(dedup_root_id IS NOT NULL AND dedup_level IN ('L1','L2','L3'),0,1) WHERE job_id=?",db::qident(STAGE_TABLE)),(job_id,))?,
            ConsolidationMode::ExactAndHighProbability=>c.exec_drop(format!("UPDATE {} SET match_eligible=IF(dedup_root_id IS NOT NULL,0,1) WHERE job_id=?",db::qident(STAGE_TABLE)),(job_id,))?,
        }
    } else {
        c.exec_drop(format!("UPDATE {} SET match_eligible=1 WHERE job_id=?",db::qident(STAGE_TABLE)),(job_id,))?;
    }
    Ok(())
}

fn terminalize_results(job_id:&str,pool:&Pool)->Result<()> {
    let mut c=pool.get_conn()?;
    c.query_drop("START TRANSACTION")?;
    let result=(||->Result<()> {
        c.exec_drop(format!(r#"INSERT INTO {results}(job_id,source_row_id,source_record_id,match_status,matched_category,matched_level,candidate_count,ambiguity_reason,result_origin)
            SELECT job_id,source_row_id,source_record_id,
                   IF(match_ambiguous_reason IS NOT NULL,'AMBIGUOUS','UNMATCHED'),
                   IF(match_ambiguous_reason IS NOT NULL,'AMBIGUOUS','UNMATCHED'),
                   match_ambiguous_level,0,match_ambiguous_reason,'DIRECT'
            FROM {stage}
            WHERE job_id=? AND match_eligible=1 AND match_state='PENDING'
            ON DUPLICATE KEY UPDATE match_status=VALUES(match_status),matched_category=VALUES(matched_category),matched_level=VALUES(matched_level),ambiguity_reason=VALUES(ambiguity_reason),result_origin='DIRECT'"#,
            results=db::qident(RESULTS_TABLE),stage=db::qident(STAGE_TABLE)),(job_id,))?;
        c.exec_drop(format!("UPDATE {} SET match_state=IF(match_ambiguous_reason IS NOT NULL,'AMBIGUOUS','UNMATCHED') WHERE job_id=? AND match_eligible=1 AND match_state='PENDING'",db::qident(STAGE_TABLE)),(job_id,))?;
        update_job_counters(&mut c,job_id)?;
        Ok(())
    })();
    match result {Ok(())=>c.query_drop("COMMIT")?,Err(e)=>{let _=c.query_drop("ROLLBACK");return Err(e);}}
    Ok(())
}

fn inherit_consolidated_results(job_id:&str,pool:&Pool)->Result<()> {
    let mut c=pool.get_conn()?;
    resolve_dedup_roots_with_conn(job_id,&mut c)?;
    c.exec_drop(format!(r#"INSERT INTO {results}(job_id,source_row_id,source_record_id,base_row_id,base_record_id,match_status,matched_category,matched_level,final_score,first_name_score,middle_name_score,last_name_score,candidate_count,second_best_score,score_margin,middle_match_type,ambiguity_reason,result_origin,dedup_group_source_row_id)
        SELECT m.job_id,m.source_row_id,m.source_record_id,r.base_row_id,r.base_record_id,r.match_status,r.matched_category,r.matched_level,r.final_score,r.first_name_score,r.middle_name_score,r.last_name_score,r.candidate_count,r.second_best_score,r.score_margin,r.middle_match_type,r.ambiguity_reason,'INHERITED_DEDUP',m.dedup_root_id
        FROM {stage} m JOIN {results} r ON r.job_id=m.job_id AND r.source_row_id=m.dedup_root_id
        WHERE m.job_id=? AND m.match_eligible=0 AND m.dedup_root_id IS NOT NULL
        ON DUPLICATE KEY UPDATE base_row_id=VALUES(base_row_id),base_record_id=VALUES(base_record_id),match_status=VALUES(match_status),matched_category=VALUES(matched_category),matched_level=VALUES(matched_level),final_score=VALUES(final_score),first_name_score=VALUES(first_name_score),middle_name_score=VALUES(middle_name_score),last_name_score=VALUES(last_name_score),candidate_count=VALUES(candidate_count),second_best_score=VALUES(second_best_score),score_margin=VALUES(score_margin),middle_match_type=VALUES(middle_match_type),ambiguity_reason=VALUES(ambiguity_reason),result_origin='INHERITED_DEDUP',dedup_group_source_row_id=VALUES(dedup_group_source_row_id)"#,
        results=db::qident(RESULTS_TABLE),stage=db::qident(STAGE_TABLE)),(job_id,))?;
    c.exec_drop(format!(r#"UPDATE {stage} m JOIN {results} r ON r.job_id=m.job_id AND r.source_row_id=m.source_row_id
        SET m.match_state=r.match_status WHERE m.job_id=? AND m.match_eligible=0"#,stage=db::qident(STAGE_TABLE),results=db::qident(RESULTS_TABLE)),(job_id,))?;
    update_job_counters(&mut c,job_id)?;
    Ok(())
}

fn finalize_dedup_only(job_id:&str,pool:&Pool)->Result<()> {
    let mut c=pool.get_conn()?;
    update_job_counters(&mut c,job_id)?;
    c.exec_drop(format!("UPDATE {} SET status='DONE',current_phase='DONE',finished_at=NOW(),updated_at=NOW() WHERE job_id=?",db::qident(JOBS_TABLE)),(job_id,))?;
    Ok(())
}

fn increment_match_counters(c: &mut PooledConn, job_id: &str, newly_matched: u64, candidates: u64) -> Result<()> {
    c.exec_drop(
        format!("UPDATE {} SET matched_rows=matched_rows+?,processed_rows=processed_rows+?,candidates_scored=candidates_scored+?,updated_at=NOW() WHERE job_id=?", db::qident(JOBS_TABLE)),
        (newly_matched, newly_matched, candidates, job_id),
    )?;
    Ok(())
}

fn update_job_counters(c:&mut PooledConn,job_id:&str)->Result<()> {
    c.exec_drop(format!(r#"UPDATE {jobs} j SET
        processed_rows=(SELECT COUNT(*) FROM {results} r WHERE r.job_id=j.job_id),
        matched_rows=(SELECT COUNT(*) FROM {results} r WHERE r.job_id=j.job_id AND r.match_status='MATCHED'),
        ambiguous_rows=(SELECT COUNT(*) FROM {results} r WHERE r.job_id=j.job_id AND r.match_status='AMBIGUOUS'),
        unmatched_rows=(SELECT COUNT(*) FROM {results} r WHERE r.job_id=j.job_id AND r.match_status='UNMATCHED'),
        invalid_rows=(SELECT COUNT(*) FROM {results} r WHERE r.job_id=j.job_id AND r.match_status='INVALID'),
        duplicate_rows=(SELECT COUNT(*) FROM {stage} s WHERE s.job_id=j.job_id AND s.dedup_root_id IS NOT NULL),
        retained_rows=(SELECT COUNT(*) FROM {stage} s WHERE s.job_id=j.job_id AND s.match_eligible=1),
        candidates_scored=(SELECT COALESCE(SUM(candidates),0) FROM {stats} ls WHERE ls.job_id=j.job_id),updated_at=NOW()
        WHERE j.job_id=?"#,jobs=db::qident(JOBS_TABLE),results=db::qident(RESULTS_TABLE),stage=db::qident(STAGE_TABLE),stats=db::qident(LEVEL_STATS_TABLE)),(job_id,))?;
    Ok(())
}

fn reconcile(job_id:&str,cfg:&AppConfig,pool:&Pool)->Result<()> {
    let mut c=pool.get_conn()?;
    let total:u64=c.exec_first(format!("SELECT COUNT(*) FROM {} WHERE job_id=?",db::qident(STAGE_TABLE)),(job_id,))?.unwrap_or(0);
    if matches!(cfg.mode,ProcessMode::DedupOnly) {
        let dup:u64=c.exec_first(format!("SELECT COUNT(*) FROM {} WHERE job_id=? AND dedup_root_id IS NOT NULL",db::qident(STAGE_TABLE)),(job_id,))?.unwrap_or(0);
        let roots:u64=c.exec_first(format!("SELECT COUNT(*) FROM {} WHERE job_id=? AND dedup_root_id IS NULL",db::qident(STAGE_TABLE)),(job_id,))?.unwrap_or(0);
        if dup+roots!=total {
            c.exec_drop(format!("UPDATE {} SET status='RECONCILIATION_FAILED' WHERE job_id=?",db::qident(JOBS_TABLE)),(job_id,))?;
            bail!("Dedup reconciliation failed: total={total}, duplicate members={dup}, retained/root records={roots}");
        }
    } else {
        let results:u64=c.exec_first(format!("SELECT COUNT(*) FROM {} WHERE job_id=?",db::qident(RESULTS_TABLE)),(job_id,))?.unwrap_or(0);
        if results!=total {
            c.exec_drop(format!("UPDATE {} SET status='RECONCILIATION_FAILED' WHERE job_id=?",db::qident(JOBS_TABLE)),(job_id,))?;
            bail!("Matching reconciliation failed: staged source rows={total}, terminal result rows={results}. Job was not marked DONE.");
        }
    }
    Ok(())
}

fn refresh_snapshot(job_id:&str,pool:&Pool,similarity:&SimilarityEngine)->Result<JobSnapshot> {
    let mut c=pool.get_conn()?;
    let row:Option<(String,Option<String>,Option<String>,u64,u64,u64,u64,u64,u64,u64,u64,f64)>=c.exec_first(format!(r#"SELECT status,current_phase,current_level,total_source_rows,processed_rows,matched_rows,ambiguous_rows,unmatched_rows,invalid_rows,duplicate_rows,retained_rows,
        COALESCE(TIMESTAMPDIFF(MICROSECOND,started_at,NOW())/1000000.0,0) FROM {} WHERE job_id=?"#,db::qident(JOBS_TABLE)),(job_id,))?;
    let Some((status,phase,level,total,processed,matched,ambiguous,unmatched,invalid,duplicates,retained,elapsed))=row else {bail!("Job not found: {job_id}");};
    let candidates:u64=c.exec_first(format!("SELECT COALESCE(SUM(candidates),0) FROM {} WHERE job_id=?",db::qident(LEVEL_STATS_TABLE)),(job_id,))?.unwrap_or(0);
    let cursor:Option<u64>=c.exec_first(format!("SELECT MAX(last_source_row_id) FROM {} WHERE job_id=?",db::qident(LEVEL_STATS_TABLE)),(job_id,))?;
    let sys=crate::resources::system_snapshot();
    let total_mem=sys.memory_total_gb;
    let used=sys.memory_used_gb;
    let mem_pct=sys.memory_percent;
    Ok(JobSnapshot{
        job_id:job_id.into(),status,phase:phase.unwrap_or_default(),level:level.unwrap_or_default(),total_source_rows:total,processed_rows:processed,matched_rows:matched,ambiguous_rows:ambiguous,unmatched_rows:unmatched,invalid_rows:invalid,duplicate_rows:duplicates,retained_rows:retained,candidates_scored:candidates,
        rows_per_second:if elapsed>0.0{processed as f64/elapsed}else{0.0},cpu_percent:sys.cpu_percent,memory_percent:mem_pct,memory_used_gb:used,memory_total_gb:total_mem,
        gpu_name:similarity.gpu_name.clone(),gpu_backend:similarity.gpu_backend.clone(),gpu_active:similarity.gpu_active,checkpoint:cursor.map(|x| format!("source row {}", fmt_u64(x))).unwrap_or_else(||"Not started".into()),message:String::new(),
    })
}

fn publish_snapshot(job_id:&str,pool:&Pool,similarity:&SimilarityEngine,tx:&Sender<EngineEvent>)->Result<()> {
    let s=refresh_snapshot(job_id,pool,similarity)?;
    let mut c=pool.get_conn()?;
    c.exec_drop(format!("INSERT INTO {}(job_id,phase,level_name,cpu_percent,memory_percent,memory_used_gb,gpu_active,rows_per_second) VALUES(?,?,?,?,?,?,?,?)",db::qident(METRICS_TABLE)),(&s.job_id,&s.phase,&s.level,s.cpu_percent,s.memory_percent,s.memory_used_gb,s.gpu_active,s.rows_per_second))?;
    let _=tx.send(EngineEvent::Snapshot(s));
    Ok(())
}

pub fn load_job_snapshot(destination:&crate::model::DbConfig,job_id:&str)->Result<JobSnapshot>{
    let pool=db::pool(destination)?;
    let dummy=SimilarityEngine::new(crate::model::GpuMode::CpuOnly,usize::MAX);
    refresh_snapshot(job_id,&pool,&dummy)
}

pub fn list_recent_jobs(destination:&crate::model::DbConfig,limit:usize)->Result<Vec<(String,String,String,String,u64,u64,u64)>>{
    let pool=db::pool(destination)?;let mut c=pool.get_conn()?;
    let sql=format!("SELECT job_id,process_mode,status,COALESCE(current_level,''),total_source_rows,matched_rows,ambiguous_rows FROM {} ORDER BY updated_at DESC LIMIT {}",db::qident(JOBS_TABLE),limit.min(500));
    Ok(c.query(sql)?)
}
