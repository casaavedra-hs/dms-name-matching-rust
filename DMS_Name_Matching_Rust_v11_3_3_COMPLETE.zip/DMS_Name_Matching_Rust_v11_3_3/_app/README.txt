DMS NAME MATCHING RUST v11.3.3

RUN ONLY: DMS Name Matching.bat

This release is recovery-first. Before downloading Rust it automatically searches previous DMS folders on the
same parent drive/folder for complete Rust 1.98.1 toolchains and Cargo caches already downloaded by prior attempts.
It prefers x86_64-pc-windows-gnullvm first (no external dlltool requirement), then x86_64-pc-windows-gnu as fallback.
For GNU it automatically exposes/copies a compatible dlltool when one exists.

The first successful build creates _app\bin\DMS_Name_Matching.exe. After that, the BAT launches the EXE directly
and Rust/Cargo/network access is no longer part of startup.
