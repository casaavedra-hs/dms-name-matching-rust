const $ = (id) => document.getElementById(id);
const fmt = (n) => new Intl.NumberFormat('en-US').format(Number(n || 0));
const pct = (n) => `${Number(n || 0).toFixed(1)}%`;
let boot = null;
let initialConfig = null;
let selectedMode = 'NameMatchOnly';
let selectedLevels = new Set(['L01','L02','L03','L04','L05','L06','L07']);
let paused = false;
let pollTimer = null;

async function api(path, options={}) {
  const opts = {...options};
  opts.headers = {'Content-Type':'application/json', ...(opts.headers||{})};
  if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
  const r = await fetch(path, opts);
  let j;
  try { j = await r.json(); } catch { throw new Error(`Invalid response from local Rust service (${r.status})`); }
  if (!j.ok) throw new Error(j.error || 'Request failed');
  return j.data;
}

function showAlert(message, type='info', timeout=7000) {
  if (!message) return;
  const area = $('alertArea');
  const el = document.createElement('div');
  el.className = `alert ${type}`;
  el.textContent = message;
  area.replaceChildren(el);
  if (timeout) setTimeout(() => { if (area.contains(el)) area.replaceChildren(); }, timeout);
}

function setPage(page) {
  document.querySelectorAll('.nav-item').forEach(x => x.classList.toggle('active', x.dataset.page === page));
  document.querySelectorAll('.page').forEach(x => x.classList.toggle('active', x.id === `page-${page}`));
  const meta = {
    dashboard:['Dashboard','Monitor matching, deduplication, quality and resource usage.'],
    process:['New Process','Configure a reliable exact-first and residual-fuzzy matching workflow.'],
    reports:['Reports','Review yield, ambiguity, data quality and reconciliation.'],
    history:['History','Review recent processing jobs and checkpoints.'],
    settings:['Settings','Tune CPU, memory, GPU and matching thresholds.']
  }[page];
  $('pageTitle').textContent = meta[0]; $('pageSubtitle').textContent = meta[1];
  if (page === 'history') loadHistory().catch(e=>showAlert(e.message,'error'));
}

document.querySelectorAll('.nav-item').forEach(x => x.addEventListener('click', () => setPage(x.dataset.page)));

function dbFormHtml(name, cfg) {
  const esc = (v='') => String(v).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
  return `<div class="form-grid">
    <div><div class="label">Host</div><input class="input" id="${name}_host" value="${esc(cfg.host)}"></div>
    <div><div class="label">Port</div><input class="input" type="number" id="${name}_port" value="${cfg.port||3306}"></div>
    <div><div class="label">User</div><input class="input" id="${name}_user" value="${esc(cfg.user)}"></div>
    <div><div class="label">Password</div><input class="input" type="password" id="${name}_password" value=""></div>
    <div class="wide"><div class="label">Database</div><input class="input" list="${name}_databases" id="${name}_database" value="${esc(cfg.database)}"><datalist id="${name}_databases"></datalist></div>
    <div class="wide"><div class="label">Table</div><input class="input" list="${name}_tables" id="${name}_table" value="${esc(cfg.table)}"><datalist id="${name}_tables"></datalist></div>
    <div class="wide button-row wrap"><button class="btn ghost" data-db-test="${name}">Test</button><button class="btn ghost" data-db-list="${name}">Load databases</button><button class="btn ghost" data-table-list="${name}">Load tables</button><button class="btn ghost" data-column-suggest="${name}">Suggest fields</button></div>
  </div>`;
}

function buildDbForms(cfg) {
  document.querySelectorAll('.db-form').forEach(el => { el.innerHTML = dbFormHtml(el.dataset.db, cfg[el.dataset.db]); });
  document.querySelectorAll('[data-db-test]').forEach(b => b.addEventListener('click', async()=>{
    try { const d=await api('/api/db/test',{method:'POST',body:getDb(b.dataset.dbTest)}); showAlert(`Connection successful · ${d.version}`,'success'); } catch(e){showAlert(e.message,'error',0)}
  }));
  document.querySelectorAll('[data-db-list]').forEach(b => b.addEventListener('click', async()=>{
    try { const vals=await api('/api/db/databases',{method:'POST',body:getDb(b.dataset.dbList)}); fillDatalist(`${b.dataset.dbList}_databases`,vals); showAlert(`${vals.length} databases loaded.`,'success'); } catch(e){showAlert(e.message,'error',0)}
  }));
  document.querySelectorAll('[data-table-list]').forEach(b => b.addEventListener('click', async()=>{
    try { const vals=await api('/api/db/tables',{method:'POST',body:getDb(b.dataset.tableList)}); fillDatalist(`${b.dataset.tableList}_tables`,vals); showAlert(`${vals.length} tables loaded.`,'success'); } catch(e){showAlert(e.message,'error',0)}
  }));
  document.querySelectorAll('[data-column-suggest]').forEach(b => b.addEventListener('click', ()=>suggestFields(b.dataset.columnSuggest)));
}

function fillDatalist(id, vals){ const el=$(id); el.innerHTML=(vals||[]).map(v=>`<option value="${String(v).replaceAll('"','&quot;')}">`).join(''); }
function getDb(name){ return {host:$(`${name}_host`).value.trim(),port:Number($(`${name}_port`).value||3306),user:$(`${name}_user`).value.trim(),password:$(`${name}_password`).value,database:$(`${name}_database`).value.trim(),table:$(`${name}_table`).value.trim()}; }

const fieldDefs = [
  ['row_key','Unique row key'],['person_id','Person/business ID'],['first_name','First name'],['middle_name','Middle name'],['middle_initial','Middle initial'],['last_name','Last name'],['birthdate','Birthdate'],['barangay_code','Barangay code'],['city_code','City/Municipality code']
];
function fieldMapHtml(name, map){ return `<div class="field-grid">${fieldDefs.map(([k,l])=>`<label>${l}<input class="input" id="${name}_${k}" value="${map[k]||''}"></label>`).join('')}</div>`; }
function buildFieldMaps(cfg){ document.querySelectorAll('.field-map').forEach(el=>el.innerHTML=fieldMapHtml(el.dataset.map,cfg[el.dataset.map])); }
function getFieldMap(name){ const o={}; fieldDefs.forEach(([k])=>o[k]=$(`${name}_${k}`).value.trim()); return o; }

async function suggestFields(dbName){
  try{
    const cols=await api('/api/db/columns',{method:'POST',body:getDb(dbName)});
    const names=cols.map(c=>c.name); const lower=new Map(names.map(n=>[n.toLowerCase(),n]));
    const mapName = dbName==='source1'?'source1_fields':dbName==='source2'?'source2_fields':null;
    if(!mapName){showAlert('Field mapping is only used for source tables.','info');return;}
    const aliases={row_key:['id','source_id','row_id'],person_id:['person_id','id','uuid'],first_name:['first_name','firstname','fname'],middle_name:['middle_name','middlename','mname'],middle_initial:['middle_initial','middleinitial','mi'],last_name:['last_name','lastname','lname','surname'],birthdate:['birthdate','birthday','dob','date_of_birth'],barangay_code:['barangay_code','brgy_code','barangay'],city_code:['city_code','municipality_code','city_mun_code','city']};
    for(const [k,list] of Object.entries(aliases)){const found=list.map(x=>lower.get(x)).find(Boolean);if(found&&$(`${mapName}_${k}`))$(`${mapName}_${k}`).value=found;}
    showAlert(`Loaded ${cols.length} columns and applied matching field suggestions.`,'success');
  }catch(e){showAlert(e.message,'error',0)}
}

function buildLevels(core, advanced){
  const exact=$('exactLevels'), fuzzy=$('fuzzyLevels'), adv=$('advancedLevels'); exact.innerHTML='';fuzzy.innerHTML='';adv.innerHTML='';
  core.forEach(l=>(l.phase==='Exact'?exact:fuzzy).appendChild(levelRow(l)));
  advanced.forEach(l=>adv.appendChild(levelRow(l)));
  updatePlan();
}
function levelRow(l){
  const d=document.createElement('label');d.className='level-row';
  d.innerHTML=`<input type="checkbox" class="level-check" value="${l.value}" ${selectedLevels.has(l.value)?'checked':''}><span class="code">${l.code}</span><span class="desc">${l.label}</span><span class="phase">${l.phase}</span>`;
  d.querySelector('input').addEventListener('change',e=>{if(e.target.checked)selectedLevels.add(l.value);else selectedLevels.delete(l.value);updatePlan();});return d;
}
function updatePlan(){
  const order=[...document.querySelectorAll('.level-check:checked')].map(x=>({v:x.value,code:x.parentElement.querySelector('.code').textContent,phase:x.parentElement.querySelector('.phase').textContent}));
  $('exactPlan').textContent=order.filter(x=>x.phase==='Exact').map(x=>x.code).join(' → ')||'No exact levels selected';
  $('fuzzyPlan').textContent=order.filter(x=>x.phase==='Fuzzy').map(x=>x.code).join(' → ')||'No fuzzy levels selected';
}

function setMode(mode){
  selectedMode=mode;document.querySelectorAll('.mode-card').forEach(x=>x.classList.toggle('selected',x.dataset.mode===mode));
  const dedupOnly=mode==='DedupOnly';
  $('source2Card').hidden=dedupOnly;$('fields2Card').hidden=dedupOnly;$('consolidationCard').hidden=mode!=='DedupConsolidateMatch';
  $('source1Title').textContent=dedupOnly?'Single source to deduplicate':'Source 1 · Base / reference';
  $('fields1Title').textContent=dedupOnly?'Single source fields':'Source 1 fields';
}
document.querySelectorAll('.mode-card').forEach(x=>x.addEventListener('click',()=>setMode(x.dataset.mode)));

function setRadio(name,value){const el=document.querySelector(`input[name="${name}"][value="${value}"]`);if(el)el.checked=true;}
function radioValue(name,def){return document.querySelector(`input[name="${name}"]:checked`)?.value||def;}
function num(id,def=0){return Number($(id).value||def);}
function loadSettings(cfg){
  const p=cfg.performance,t=cfg.thresholds;
  ['cpu_workers','cpu_reserve_cores','memory_limit_percent','min_free_ram_gb','exact_batch_size','fuzzy_source_chunk','fuzzy_candidate_cap','gpu_min_field_pairs'].forEach(k=>$(k).value=p[k]);
  ['l5','l6','l7','l5_component_min','fuzzy_middle_min_l5','fuzzy_middle_min_l7','minimum_margin'].forEach(k=>$(k).value=t[k]);
  setRadio('gpu_mode',p.gpu_mode);$('rebuild_base_index').checked=!!cfg.rebuild_base_index;
}
function collectConfig(){
  const cfg=structuredClone(initialConfig||{});
  cfg.mode=selectedMode;cfg.consolidation=radioValue('consolidation','ExactOnly');
  cfg.source1=getDb('source1');cfg.source2=getDb('source2');cfg.destination=getDb('destination');
  cfg.source1_fields=getFieldMap('source1_fields');cfg.source2_fields=getFieldMap('source2_fields');
  cfg.selected_levels=[...selectedLevels].sort((a,b)=>Number(a.slice(1))-Number(b.slice(1)));
  cfg.rebuild_base_index=$('rebuild_base_index').checked;
  cfg.performance={cpu_workers:num('cpu_workers',1),cpu_reserve_cores:num('cpu_reserve_cores',2),memory_limit_percent:num('memory_limit_percent',82),min_free_ram_gb:num('min_free_ram_gb',8),exact_batch_size:num('exact_batch_size',100000),fuzzy_source_chunk:num('fuzzy_source_chunk',2500),fuzzy_candidate_cap:num('fuzzy_candidate_cap',100),gpu_mode:radioValue('gpu_mode','Auto'),gpu_min_field_pairs:num('gpu_min_field_pairs',20000)};
  cfg.thresholds={...cfg.thresholds,l5:num('l5',92),l6:num('l6',94),l7:num('l7',95),l15:Number(cfg.thresholds?.l15||96),minimum_margin:num('minimum_margin',3),l5_component_min:num('l5_component_min',90),fuzzy_middle_min_l5:num('fuzzy_middle_min_l5',90),fuzzy_middle_min_l7:num('fuzzy_middle_min_l7',92)};
  return cfg;
}

async function saveConfig(){const cfg=collectConfig();await api('/api/config/save',{method:'POST',body:{config:cfg,remember_passwords:$('rememberPasswords').checked}});initialConfig=structuredClone(cfg);showAlert('Configuration saved.','success');}
async function startJob(resume=false){
  const cfg=collectConfig(); if(!cfg.selected_levels.length)throw new Error('Select at least one matching level.');
  const job_id=resume?$('resumeJobId').value.trim():'';if(resume&&!job_id)throw new Error('Enter the Job ID to resume.');
  const d=await api(resume?'/api/job/resume':'/api/job/start',{method:'POST',body:{config:cfg,job_id}});$('reportJobId').value=d.job_id;showAlert(`${resume?'Resume':'Processing'} started · ${d.job_id}`,'success');setPage('dashboard');await refreshState();
}

function updateRuntime(data){
  boot=data;const s=data.snapshot||{};const total=Number(s.total_source_rows||0),processed=Number(s.processed_rows||0),progress=total?Math.min(100,processed/total*100):0;
  $('versionLabel').textContent=data.app_version||'Rust';$('engineStatus').textContent=data.running?(data.paused?'PAUSED':'RUNNING'):(s.status||'IDLE');
  $('mProcessed').textContent=fmt(processed);$('mProgress').textContent=`${progress.toFixed(1)}% of ${fmt(total)}`;$('mMatched').textContent=fmt(s.matched_rows);$('mAmbiguous').textContent=fmt(s.ambiguous_rows);$('mUnmatched').textContent=fmt(s.unmatched_rows);
  $('progressBar').style.width=`${progress}%`;$('progressText').textContent=`${fmt(processed)} / ${fmt(total)}`;$('speedText').textContent=`${fmt(Math.round(s.rows_per_second||0))} rows/sec`;
  $('phaseBadge').textContent=s.phase||'READY';$('cpuText').textContent=pct(s.cpu_percent);$('memText').textContent=pct(s.memory_percent);$('cpuBar').style.width=`${Math.min(100,s.cpu_percent||0)}%`;$('memBar').style.width=`${Math.min(100,s.memory_percent||0)}%`;
  $('gpuBadge').textContent=s.gpu_active?'GPU ACTIVE':(s.gpu_backend||'CPU');$('gpuName').textContent=s.gpu_name||'Not active';$('checkpointText').textContent=s.checkpoint||'Not started';$('currentLevel').textContent=s.level||'—';
  $('pauseBtn').disabled=!data.running;$('stopBtn').disabled=!data.running;paused=!!data.paused;$('pauseBtn').textContent=paused?'Resume processing':'Pause at checkpoint';
  $('logBox').textContent=(data.logs&&data.logs.length)?data.logs.join('\n'):'No processing log yet.';$('logBox').scrollTop=$('logBox').scrollHeight;
  if(data.error)showAlert(data.error,'error',0); else if(data.notice && data.notice!==window._lastNotice){window._lastNotice=data.notice;showAlert(data.notice,'success');}
  if(data.active_job_id&&!$('reportJobId').value)$('reportJobId').value=data.active_job_id;
}

async function refreshState(){const d=await api('/api/bootstrap');updateRuntime(d);return d;}

async function loadHistory(){
  try{const rows=await api('/api/history',{method:'POST',body:{limit:100}});$('historyTable').innerHTML=(rows||[]).map(r=>`<tr><td><button class="btn ghost use-job" data-job="${r[0]}">${r[0]}</button></td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${fmt(r[4])}</td><td>${fmt(r[5])}</td><td>${fmt(r[6])}</td></tr>`).join('')||'<tr><td colspan="7">No jobs found.</td></tr>';document.querySelectorAll('.use-job').forEach(b=>b.onclick=()=>{$('reportJobId').value=b.dataset.job;setPage('reports');loadReport().catch(e=>showAlert(e.message,'error'));});}catch(e){showAlert(e.message,'error',0)}
}
async function loadReport(){
  const job_id=$('reportJobId').value.trim();if(!job_id)throw new Error('Enter a Job ID.');const r=await api('/api/report/load',{method:'POST',body:{job_id}});
  const metrics=[['Total rows',r.total_rows],['Matched',r.matched],['Ambiguous',r.ambiguous],['Unmatched',r.unmatched],['Duplicates',r.duplicates],['Retained',r.retained],['Direct matches',r.direct_matches],['Inherited matches',r.inherited_matches],['Middle fuzzy',r.middle_fuzzy],['Candidate-cap ambiguity',r.candidate_cap_ambiguities],['Score-margin ambiguity',r.score_margin_ambiguities],['Multiple exact ambiguity',r.multiple_exact_ambiguities]];
  $('reportMetrics').innerHTML=metrics.map(([k,v])=>`<article class="metric-card"><div class="metric-label">${k}</div><div class="metric-value">${fmt(v)}</div></article>`).join('');
  $('levelTable').innerHTML=(r.level_stats||[]).map(x=>`<tr><td>${x.phase}</td><td><b>${x.level}</b></td><td>${fmt(x.eligible)}</td><td>${fmt(x.matched)}</td><td>${fmt(x.ambiguous)}</td><td>${fmt(x.candidates)}</td><td>${Number(x.duration_seconds||0).toFixed(1)}s</td></tr>`).join('');
}
async function exportReport(){const job_id=$('reportJobId').value.trim();if(!job_id)throw new Error('Enter a Job ID.');const r=await api('/api/report/export',{method:'POST',body:{job_id}});showAlert(`Report package exported to ${r.path}`,'success',0);}

function wire(){
  $('refreshBtn').onclick=()=>refreshState().catch(e=>showAlert(e.message,'error'));
  $('resetLevelsBtn').onclick=()=>{selectedLevels=new Set(['L01','L02','L03','L04','L05','L06','L07']);document.querySelectorAll('.level-check').forEach(x=>x.checked=selectedLevels.has(x.value));updatePlan();};
  $('saveConfigBtn').onclick=()=>saveConfig().catch(e=>showAlert(e.message,'error',0));$('saveSettingsBtn').onclick=()=>saveConfig().catch(e=>showAlert(e.message,'error',0));
  $('startBtn').onclick=()=>startJob(false).catch(e=>showAlert(e.message,'error',0));$('resumeBtn').onclick=()=>startJob(true).catch(e=>showAlert(e.message,'error',0));
  $('pauseBtn').onclick=async()=>{try{await api('/api/job/pause',{method:'POST',body:{paused:!paused}});await refreshState();}catch(e){showAlert(e.message,'error')}};
  $('stopBtn').onclick=async()=>{if(!confirm('Stop the current job at the next safe checkpoint?'))return;try{await api('/api/job/stop',{method:'POST',body:{}});await refreshState();}catch(e){showAlert(e.message,'error')}};
  $('copyLogBtn').onclick=()=>navigator.clipboard?.writeText($('logBox').textContent||'');$('loadHistoryBtn').onclick=loadHistory;
  $('loadReportBtn').onclick=()=>loadReport().catch(e=>showAlert(e.message,'error',0));$('exportReportBtn').onclick=()=>exportReport().catch(e=>showAlert(e.message,'error',0));
}

async function init(){
  try{
    const d=await api('/api/bootstrap');boot=d;initialConfig=structuredClone(d.config);selectedMode=d.config.mode;selectedLevels=new Set(d.config.selected_levels||['L01','L02','L03','L04','L05','L06','L07']);
    buildDbForms(d.config);buildFieldMaps(d.config);buildLevels(d.core_levels,d.advanced_levels);loadSettings(d.config);setMode(selectedMode);setRadio('consolidation',d.config.consolidation);updateRuntime(d);wire();
    pollTimer=setInterval(()=>refreshState().catch(()=>{}),2000);
  }catch(e){showAlert(e.message,'error',0)}
}
init();
